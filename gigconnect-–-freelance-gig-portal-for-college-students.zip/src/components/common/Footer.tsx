import React from 'react';
import { Briefcase, Heart } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Footer: React.FC = () => {
  const { setActiveTab, openAuthModal, role } = useApp();

  return (
    <footer className="bg-[#05070c] border-t border-amber-500/20 mt-auto text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-amber-500/20">
                <Briefcase className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <span className="text-lg font-extrabold tracking-tight text-white">
                Gig<span className="text-gold-gradient">Connect</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Empowering college students to monetize their tech, design, media, and writing skills with local startups and verified businesses.
            </p>
            <p className="text-[11px] text-amber-400 font-semibold pt-1">
              PBL HACKEXPO 2026 Project Demonstration
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">For Students</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => {
                    setActiveTab('find-gigs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  Explore All Gigs
                </button>
              </li>
              <li>
                <button
                  onClick={() => openAuthModal('register', 'student')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Create Student Profile
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('find-gigs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  Skill Match Search
                </button>
              </li>
              <li>
                <span className="text-slate-600">Campus Ambassador Program</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">For Businesses</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => openAuthModal('register', 'business')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Post a Gig
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (role === 'business') {
                      setActiveTab('find-students');
                    } else {
                      openAuthModal('login', 'business');
                    }
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  Browse Campus Talent
                </button>
              </li>
              <li>
                <span className="text-slate-600">Fast Turnaround Guarantee</span>
              </li>
              <li>
                <span className="text-slate-600">Escrow Milestone Payouts</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">Platform & Tech</h4>
            <div className="space-y-2 text-xs text-slate-400">
              <p>Built with React 19, TypeScript, and modern Tailwind CSS.</p>
              <p>Designed for easy integration with Java Spring Boot REST APIs & PostgreSQL/MySQL backends.</p>
              <div className="pt-2 flex items-center gap-1 text-[11px] text-slate-500">
                <span>Crafted with</span>
                <Heart className="w-3 h-3 text-amber-500 fill-amber-500" />
                <span>for college innovation</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-amber-500/15 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© 2026 GigConnect Technologies. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-amber-400 cursor-pointer">Privacy Policy</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-amber-400 cursor-pointer">Terms of Service</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-amber-400 cursor-pointer">Campus Guidelines</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
