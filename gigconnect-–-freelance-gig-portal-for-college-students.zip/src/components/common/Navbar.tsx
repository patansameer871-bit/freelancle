import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  MessageSquare,
  Menu,
  X,
  Briefcase,
  PlusCircle,
  LogOut,
  ChevronDown
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    role,
    currentStudent,
    currentBusiness,
    activeTab,
    setActiveTab,
    notifications,
    setNotificationsOpen,
    setMessagesOpen,
    openAuthModal,
    setPostGigModalOpen,
    logout
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const unreadNotifications = notifications.filter(n => !n.read).length;

  const handleNavClick = (tab: string) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#090a0f]/95 backdrop-blur-md border-b border-amber-500/20 shadow-md shadow-black/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single text element Brand Zone */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick(role === 'guest' ? 'landing' : 'dashboard')}
              className="flex items-center gap-2.5 group text-left"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-300 via-amber-500 to-yellow-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-amber-500/20 transition-transform group-hover:scale-105">
                <Briefcase className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-white group-hover:text-amber-400 transition-colors">
                Gig<span className="text-gold-gradient">Connect</span>
              </span>
            </button>

            {role !== 'guest' && (
              <span className="hidden sm:inline text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                {role === 'student' ? 'Student Portal' : 'Client Portal'}
              </span>
            )}
          </div>

          {/* Zone 2: Clean text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
            {role === 'guest' ? (
              <>
                <button
                  onClick={() => handleNavClick('landing')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'landing' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Home
                </button>
                <button
                  onClick={() => handleNavClick('find-gigs')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'find-gigs' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Find Gigs
                </button>
                <button
                  onClick={() => {
                    handleNavClick('landing');
                    setTimeout(() => {
                      document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  How It Works
                </button>
                <button
                  onClick={() => {
                    handleNavClick('landing');
                    setTimeout(() => {
                      document.getElementById('about-section')?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  About
                </button>
              </>
            ) : role === 'student' ? (
              <>
                <button
                  onClick={() => handleNavClick('dashboard')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'dashboard' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => handleNavClick('find-gigs')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'find-gigs' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Discover Gigs
                </button>
                <button
                  onClick={() => handleNavClick('my-applications')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'my-applications' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  My Applications
                </button>
                <button
                  onClick={() => handleNavClick('saved-gigs')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'saved-gigs' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Saved Gigs
                </button>
                <button
                  onClick={() => handleNavClick('profile')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'profile' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Profile
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => handleNavClick('dashboard')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'dashboard' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => handleNavClick('my-gigs')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'my-gigs' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  My Active Gigs
                </button>
                <button
                  onClick={() => handleNavClick('applications')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'applications' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Applications
                </button>
                <button
                  onClick={() => handleNavClick('find-students')}
                  className={`hover:text-amber-400 transition-colors ${
                    activeTab === 'find-students' ? 'text-amber-400 font-semibold' : ''
                  }`}
                >
                  Find Talent
                </button>
              </>
            )}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-3">
            {role === 'guest' ? (
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => openAuthModal('login', 'student')}
                  className="px-3.5 py-2 text-xs font-semibold text-amber-200 hover:text-white transition-colors"
                >
                  Login
                </button>
                <button
                  onClick={() => openAuthModal('register', 'student')}
                  className="px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 rounded-lg hover:from-amber-300 hover:to-yellow-400 shadow-md shadow-amber-500/20 transition-all hover:scale-102"
                >
                  Get Started
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {role === 'business' && (
                  <button
                    onClick={() => setPostGigModalOpen(true)}
                    className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 rounded-lg hover:from-amber-300 hover:to-amber-400 transition-colors shadow-sm"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Post a Gig</span>
                  </button>
                )}

                {/* Notifications trigger */}
                <button
                  onClick={() => setNotificationsOpen(true)}
                  className="relative p-2 text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg transition-colors border border-transparent hover:border-amber-500/20"
                  title="Notifications"
                >
                  <Bell className="w-4 h-4" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-400 rounded-full shadow-sm shadow-amber-400" />
                  )}
                </button>

                {/* Chat trigger */}
                <button
                  onClick={() => setMessagesOpen(true)}
                  className="p-2 text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg transition-colors border border-transparent hover:border-amber-500/20"
                  title="Direct Messages"
                >
                  <MessageSquare className="w-4 h-4" />
                </button>

                {/* Profile menu */}
                <div className="relative">
                  <button
                    onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                    className="flex items-center gap-2 p-1 pl-2 pr-1.5 rounded-lg border border-amber-500/30 bg-slate-900 hover:bg-slate-800 transition-colors text-left"
                  >
                    <img
                      src={role === 'student' ? currentStudent.avatar : currentBusiness.avatar}
                      alt="Avatar"
                      className="w-6 h-6 rounded-full bg-slate-800 border border-amber-500/40"
                    />
                    <span className="text-xs font-medium text-slate-200 max-w-[90px] truncate hidden md:inline">
                      {role === 'student' ? currentStudent.name.split(' ')[0] : currentBusiness.companyName.split(' ')[0]}
                    </span>
                    <ChevronDown className="w-3 h-3 text-amber-400" />
                  </button>

                  {profileDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-slate-900 rounded-xl shadow-2xl border border-amber-500/30 py-1.5 z-50">
                      <div className="px-3.5 py-2 border-b border-slate-800">
                        <p className="text-xs font-semibold text-white truncate">
                          {role === 'student' ? currentStudent.name : currentBusiness.name}
                        </p>
                        <p className="text-[11px] text-amber-400/80 truncate">
                          {role === 'student' ? currentStudent.college : currentBusiness.companyName}
                        </p>
                      </div>

                      {role === 'student' ? (
                        <>
                          <button
                            onClick={() => {
                              setActiveTab('profile');
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left px-3.5 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400"
                          >
                            My Profile & Skills
                          </button>
                          <button
                            onClick={() => {
                              setActiveTab('my-applications');
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left px-3.5 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400"
                          >
                            My Applications
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setActiveTab('my-gigs');
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left px-3.5 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400"
                          >
                            Manage Gigs
                          </button>
                          <button
                            onClick={() => {
                              setActiveTab('applications');
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left px-3.5 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-amber-400"
                          >
                            Review Candidates
                          </button>
                        </>
                      )}

                      <div className="border-t border-slate-800 my-1" />
                      <button
                        onClick={() => {
                          logout();
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full text-left px-3.5 py-2 text-xs text-rose-400 hover:bg-rose-950/40 flex items-center gap-1.5"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-300 hover:text-amber-400 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-amber-500/20 bg-slate-950 px-4 pt-2 pb-4 space-y-2">
          {role === 'guest' ? (
            <div className="flex flex-col space-y-1">
              <button
                onClick={() => handleNavClick('landing')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Home
              </button>
              <button
                onClick={() => handleNavClick('find-gigs')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Find Gigs
              </button>
              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    openAuthModal('login', 'student');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2 text-xs font-semibold text-amber-200 border border-amber-500/30 rounded-lg"
                >
                  Log In
                </button>
                <button
                  onClick={() => {
                    openAuthModal('register', 'student');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 rounded-lg"
                >
                  Get Started
                </button>
              </div>
            </div>
          ) : role === 'student' ? (
            <div className="flex flex-col space-y-1">
              <button
                onClick={() => handleNavClick('dashboard')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Dashboard
              </button>
              <button
                onClick={() => handleNavClick('find-gigs')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Find Gigs
              </button>
              <button
                onClick={() => handleNavClick('my-applications')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                My Applications
              </button>
              <button
                onClick={() => handleNavClick('saved-gigs')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Saved Gigs
              </button>
              <button
                onClick={() => handleNavClick('profile')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                My Profile
              </button>
            </div>
          ) : (
            <div className="flex flex-col space-y-1">
              <button
                onClick={() => handleNavClick('dashboard')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Dashboard
              </button>
              <button
                onClick={() => handleNavClick('my-gigs')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                My Gigs
              </button>
              <button
                onClick={() => handleNavClick('applications')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Applications
              </button>
              <button
                onClick={() => handleNavClick('find-students')}
                className="w-full text-left px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-slate-900 rounded-lg"
              >
                Find Students
              </button>
              <button
                onClick={() => {
                  setPostGigModalOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="w-full mt-2 py-2 text-xs font-bold text-slate-900 bg-gradient-to-r from-amber-400 to-amber-500 rounded-lg"
              >
                + Post a New Gig
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
