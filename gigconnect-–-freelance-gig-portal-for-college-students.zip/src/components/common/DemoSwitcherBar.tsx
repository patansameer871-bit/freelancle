import React from 'react';
import { useApp } from '../../context/AppContext';
import { Sparkles, User, Building2, Eye, RotateCcw } from 'lucide-react';

export const DemoSwitcherBar: React.FC = () => {
  const { role, switchRole, resetAllData, currentStudent, currentBusiness } = useApp();

  return (
    <div className="bg-[#050608] text-slate-300 text-xs border-b border-amber-500/20 px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 z-50">
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1.5 font-bold text-amber-400">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>Hackathon Demo Switcher:</span>
        </span>
        <span className="text-slate-400 hidden sm:inline">PBL HACKEXPO 2026 Showcase Mode</span>
      </div>

      <div className="flex items-center gap-1.5 flex-wrap">
        <button
          onClick={() => switchRole('student')}
          className={`px-2.5 py-1 rounded text-xs font-semibold transition-all flex items-center gap-1.5 ${
            role === 'student'
              ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-sm ring-1 ring-amber-300'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-amber-500/20'
          }`}
          title="Login as Aarav Sharma (Student)"
        >
          <User className="w-3 h-3" />
          <span>Student ({currentStudent.name.split(' ')[0]})</span>
        </button>

        <button
          onClick={() => switchRole('business')}
          className={`px-2.5 py-1 rounded text-xs font-semibold transition-all flex items-center gap-1.5 ${
            role === 'business'
              ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-sm ring-1 ring-amber-300'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-amber-500/20'
          }`}
          title="Login as TechNova Labs (Business Client)"
        >
          <Building2 className="w-3 h-3" />
          <span>Business ({currentBusiness.companyName.split(' ')[0]})</span>
        </button>

        <button
          onClick={() => switchRole('guest')}
          className={`px-2.5 py-1 rounded text-xs font-semibold transition-all flex items-center gap-1.5 ${
            role === 'guest'
              ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-sm ring-1 ring-amber-300'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-amber-500/20'
          }`}
          title="Browse as Guest Visitor"
        >
          <Eye className="w-3 h-3" />
          <span>Public Landing</span>
        </button>

        <span className="h-3 w-px bg-slate-800 mx-1 hidden sm:inline" />

        <button
          onClick={resetAllData}
          className="px-2 py-1 rounded text-xs text-slate-400 hover:text-amber-400 hover:bg-slate-900 transition-colors flex items-center gap-1"
          title="Reset to default mock data"
        >
          <RotateCcw className="w-3 h-3" />
          <span className="hidden md:inline">Reset Demo</span>
        </button>
      </div>
    </div>
  );
};
