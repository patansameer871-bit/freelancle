import React from 'react';
import {
  Code,
  Sparkles,
  CheckCircle2,
  Building2,
  Briefcase,
  Layers,
  ArrowRight,
  TrendingUp,
  Cpu
} from 'lucide-react';

export const HeroIllustration: React.FC = () => {
  return (
    <div className="relative w-full max-w-lg lg:max-w-none mx-auto select-none">
      {/* Background glow effects */}
      <div className="absolute -top-12 -left-8 w-72 h-72 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 -right-8 w-72 h-72 bg-yellow-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Main Glass / Modern Dark Card container */}
      <div className="relative bg-[#0d111a]/95 rounded-2xl border border-amber-500/30 shadow-2xl shadow-black/80 p-6 overflow-hidden">
        {/* Decorative subtle gold grid background */}
        <div
          className="absolute inset-0 opacity-[0.04] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#f59e0b 1px, transparent 1px)`,
            backgroundSize: '16px 16px'
          }}
        />

        {/* Top Header Simulation */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/15">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            </div>
            <span className="text-[11px] font-mono text-amber-400/60 ml-2">portal.gigconnect.io/live-match</span>
          </div>
          <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            Live Marketplace
          </span>
        </div>

        {/* Dynamic Match Visualization */}
        <div className="mt-5 space-y-4">
          {/* Top: Business Gig Card */}
          <div className="p-4 rounded-xl bg-[#131926] border border-amber-500/20 hover:border-amber-400/40 transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold text-sm shadow-md shadow-amber-500/20">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">TechNova Labs</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <p className="text-xs text-slate-400">Posted: Build Hackathon Portal</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-black text-amber-400 font-mono tracking-tight">₹14,000</span>
                <p className="text-[10px] text-amber-200/60">Escrow Secured</p>
              </div>
            </div>

            <div className="mt-3 flex items-center gap-2 text-xs text-slate-300">
              <span className="bg-slate-900/80 px-2 py-0.5 rounded border border-amber-500/20 text-[11px] text-amber-200">React</span>
              <span className="bg-slate-900/80 px-2 py-0.5 rounded border border-amber-500/20 text-[11px] text-amber-200">Tailwind</span>
              <span className="bg-slate-900/80 px-2 py-0.5 rounded border border-amber-500/20 text-[11px] text-amber-200">7 Days</span>
            </div>
          </div>

          {/* Connection Vector indicator */}
          <div className="flex items-center justify-center relative py-1">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-dashed border-amber-500/40" />
            </div>
            <div className="relative bg-[#090a0f] px-3.5 py-1 rounded-full border border-amber-500/50 shadow-md flex items-center gap-1.5 text-xs font-bold text-amber-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
              <span>96% AI Skill Compatibility</span>
            </div>
          </div>

          {/* Bottom: College Student Card */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#171f30] to-[#1a1c29] border border-amber-500/30">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src="https://api.dicebear.com/7.x/avataaars/svg?seed=Aarav&backgroundColor=c0aede,b6e3f4"
                    alt="Aarav"
                    className="w-10 h-10 rounded-full border-2 border-amber-400/80 shadow-md"
                  />
                  <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-500 border-2 border-slate-950 flex items-center justify-center text-[8px] text-slate-950 font-black">
                    ✓
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">Aarav Sharma</span>
                    <span className="text-[10px] text-amber-300 bg-amber-500/20 px-1.5 py-0.2 rounded font-semibold border border-amber-500/30">
                      MIT WPU '26
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">B.Tech CS · 4.9★ (4 Gigs Completed)</p>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 px-2 py-0.5 rounded-full">
                  Immediate Hire
                </span>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between text-xs pt-1 border-t border-amber-500/15">
              <span className="text-slate-400 font-medium">Previous: DevSprint Portal (600+ users)</span>
              <span className="text-amber-400 font-bold flex items-center gap-1">
                Matched <ArrowRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        </div>

        {/* Floating Mini metric badges */}
        <div className="mt-4 grid grid-cols-3 gap-2 text-center pt-3 border-t border-amber-500/15">
          <div className="p-2 rounded-lg bg-[#111724] border border-amber-500/15">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Fast Pay</p>
            <p className="text-xs font-black text-amber-400 font-mono">100% Escrow</p>
          </div>
          <div className="p-2 rounded-lg bg-[#111724] border border-amber-500/15">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Turnaround</p>
            <p className="text-xs font-black text-amber-400 font-mono">Avg 48h</p>
          </div>
          <div className="p-2 rounded-lg bg-[#111724] border border-amber-500/15">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Experience</p>
            <p className="text-xs font-black text-amber-400 font-mono">Portfolio CV</p>
          </div>
        </div>
      </div>
    </div>
  );
};
