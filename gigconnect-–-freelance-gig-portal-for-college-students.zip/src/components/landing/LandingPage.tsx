import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { HeroIllustration } from './HeroIllustration';
import { POPULAR_SKILLS, PLATFORM_STATS } from '../../data/mockData';
import {
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Briefcase,
  Users,
  Search,
  DollarSign,
  ShieldCheck,
  Award,
  Zap,
  Star,
  MapPin,
  Clock,
  ExternalLink,
  Code,
  Terminal,
  Palette,
  Cpu,
  Video,
  FileText,
  Table
} from 'lucide-react';
import { Gig } from '../../types';

export const LandingPage: React.FC = () => {
  const { gigs, setActiveTab, openAuthModal, setSelectedGigId, openApplyModal, role } = useApp();
  const [howItWorksTab, setHowItWorksTab] = useState<'students' | 'businesses'>('students');

  // Featured gigs
  const featuredGigs = gigs.filter(g => g.featured).slice(0, 3);

  const getSkillIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code': return <Code className="w-5 h-5 text-amber-400" />;
      case 'Terminal': return <Terminal className="w-5 h-5 text-amber-400" />;
      case 'Palette': return <Palette className="w-5 h-5 text-amber-400" />;
      case 'Cpu': return <Cpu className="w-5 h-5 text-amber-400" />;
      case 'Video': return <Video className="w-5 h-5 text-amber-400" />;
      case 'FileText': return <FileText className="w-5 h-5 text-amber-400" />;
      case 'Table': return <Table className="w-5 h-5 text-amber-400" />;
      default: return <Briefcase className="w-5 h-5 text-amber-400" />;
    }
  };

  const handleGigClick = (gig: Gig) => {
    setSelectedGigId(gig.id);
    if (role === 'guest') {
      openAuthModal('login', 'student');
    } else {
      setActiveTab('find-gigs');
    }
  };

  return (
    <div className="space-y-20 pb-16 bg-[#090a0f] text-slate-100">
      {/* 1. Hero Section */}
      <section className="relative pt-12 pb-8 sm:pt-16 sm:pb-12 overflow-hidden">
        {/* Subtle background golden ambient glow */}
        <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-b from-amber-500/10 via-yellow-600/5 to-transparent pointer-events-none" />
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-amber-500/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content (7 cols) */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-semibold text-amber-300">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>The #1 Verified Freelance Network for College Campuses</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12]">
                Turn Your Skills Into{' '}
                <span className="text-gold-gradient drop-shadow-sm">
                  Opportunities
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Connect ambitious college students with high-growth businesses and local founders for short-term freelance gigs. Build real-world portfolio proof, get paid securely, and launch your career while studying.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={() => {
                    if (role === 'guest') {
                      setActiveTab('find-gigs');
                    } else if (role === 'student') {
                      setActiveTab('find-gigs');
                    } else {
                      setActiveTab('find-students');
                    }
                  }}
                  className="w-full sm:w-auto px-7 py-3.5 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 rounded-xl hover:from-amber-300 hover:to-yellow-300 shadow-lg shadow-amber-500/25 transition-all hover:shadow-xl hover:-translate-y-0.5 flex items-center justify-center gap-2"
                >
                  <Search className="w-4 h-4 stroke-[2.5]" />
                  <span>Find Gigs</span>
                </button>

                <button
                  onClick={() => {
                    if (role === 'business') {
                      setActiveTab('my-gigs');
                    } else {
                      openAuthModal('register', 'business');
                    }
                  }}
                  className="w-full sm:w-auto px-7 py-3.5 text-sm font-bold text-amber-300 bg-[#121824] border border-amber-500/35 rounded-xl hover:bg-[#182133] hover:border-amber-400 shadow-sm transition-all flex items-center justify-center gap-2"
                >
                  <Briefcase className="w-4 h-4 text-amber-400 stroke-[2.5]" />
                  <span>Post a Gig</span>
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  <span>Verified College Students</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Guaranteed Escrow Payouts</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>Zero Commission on First Gig</span>
                </div>
              </div>
            </div>

            {/* Right Hero Artwork (5 cols) */}
            <div className="lg:col-span-5">
              <HeroIllustration />
            </div>
          </div>
        </div>
      </section>

      {/* 2. Platform Statistics Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#0e131f] rounded-2xl p-8 sm:p-10 border border-amber-500/30 shadow-2xl shadow-black/80 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 via-transparent to-amber-500/5 pointer-events-none" />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center relative z-10">
            {PLATFORM_STATS.map((stat, idx) => (
              <div key={idx} className="space-y-1 p-2">
                <p className="text-2xl sm:text-3xl lg:text-4xl font-black text-gold-gradient font-mono tabular-nums tracking-tight">
                  {stat.value}
                </p>
                <p className="text-xs sm:text-sm font-bold text-slate-200">{stat.label}</p>
                <p className="text-[11px] text-amber-200/60">{stat.subtext}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. How It Works Section */}
      <section id="how-it-works" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Simple 3-Step Process
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            How <span className="text-gold-gradient">GigConnect</span> Works
          </h2>
          <p className="text-sm text-slate-300">
            Whether you want to earn while studying or need top-tier student talent for high-priority sprints.
          </p>

          {/* Interactive Role Switcher for How It Works */}
          <div className="inline-flex p-1 bg-[#121824] rounded-xl border border-amber-500/25 mt-2">
            <button
              onClick={() => setHowItWorksTab('students')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                howItWorksTab === 'students'
                  ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              For College Students
            </button>
            <button
              onClick={() => setHowItWorksTab('businesses')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                howItWorksTab === 'businesses'
                  ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              For Businesses & Clients
            </button>
          </div>
        </div>

        {/* 3 Steps Cards */}
        {howItWorksTab === 'students' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#0f1422] p-6 rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-lg mb-4 group-hover:scale-105 transition-transform">
                01
              </div>
              <h3 className="text-base font-bold text-white mb-2">Create Your Profile</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Sign up with your college email, tag your key proficiencies (React, Java, UI/UX, Video Editing), and upload your GitHub or portfolio links.
              </p>
              <div className="pt-2 border-t border-amber-500/15 text-[11px] text-amber-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Verified student badge unlocks instantly</span>
              </div>
            </div>

            <div className="bg-[#0f1422] p-6 rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-lg mb-4 group-hover:scale-105 transition-transform">
                02
              </div>
              <h3 className="text-base font-bold text-white mb-2">Discover Gigs</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Browse curated short-term gigs with transparent budgets (₹4,000 - ₹25,000). Our algorithm highlights your skill match percentage.
              </p>
              <div className="pt-2 border-t border-amber-500/15 text-[11px] text-amber-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Smart filters for remote & hybrid schedules</span>
              </div>
            </div>

            <div className="bg-[#0f1422] p-6 rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-lg mb-4 group-hover:scale-105 transition-transform">
                03
              </div>
              <h3 className="text-base font-bold text-white mb-2">Get Hired & Paid</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Submit a short proposal, connect directly with the founder, finish deliverables, and receive secured payouts directly to your account.
              </p>
              <div className="pt-2 border-t border-amber-500/15 text-[11px] text-amber-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>100% escrow protection before kickoff</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#0f1422] p-6 rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-lg mb-4 group-hover:scale-105 transition-transform">
                01
              </div>
              <h3 className="text-base font-bold text-white mb-2">Post a Gig</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Define your project scope, required technical skills, timeline, and budget. Takes less than 2 minutes to publish live.
              </p>
              <div className="pt-2 border-t border-amber-500/15 text-[11px] text-amber-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Instant distribution to 80+ universities</span>
              </div>
            </div>

            <div className="bg-[#0f1422] p-6 rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-lg mb-4 group-hover:scale-105 transition-transform">
                02
              </div>
              <h3 className="text-base font-bold text-white mb-2">Find Talent</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Review ranked candidate profiles with verified GitHub projects, Behance designs, college credentials, and past client ratings.
              </p>
              <div className="pt-2 border-t border-amber-500/15 text-[11px] text-amber-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Ranked by automated skill match score</span>
              </div>
            </div>

            <div className="bg-[#0f1422] p-6 rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-black text-lg mb-4 group-hover:scale-105 transition-transform">
                03
              </div>
              <h3 className="text-base font-bold text-white mb-2">Hire Students</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Shortlist, chat, and accept candidates in 1 click. Work gets executed fast without agency overhead or long procurement delays.
              </p>
              <div className="pt-2 border-t border-amber-500/15 text-[11px] text-amber-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Average hiring turnaround under 48 hours</span>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* 4. Featured Gigs Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              High-Demand Gigs
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Featured Opportunities
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Verified freelance contracts open for student applications right now.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('find-gigs')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View all {gigs.length} gigs</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredGigs.map(gig => (
            <div
              key={gig.id}
              className="bg-[#0e131f] rounded-2xl border border-amber-500/20 hover:border-amber-400/50 hover:shadow-2xl transition-all p-6 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <span className="text-[11px] font-semibold text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                    {gig.category}
                  </span>
                  <span className="text-sm font-bold text-amber-400 font-mono">
                    ₹{gig.minBudget.toLocaleString()} - ₹{gig.maxBudget.toLocaleString()}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white hover:text-amber-400 transition-colors line-clamp-1">
                  {gig.title}
                </h3>
                <p className="text-xs font-medium text-slate-300 mt-1 flex items-center gap-1">
                  <span>{gig.businessName}</span>
                  {gig.businessVerified && (
                    <CheckCircle2 className="w-3 h-3 text-amber-400 shrink-0" />
                  )}
                </p>

                <p className="text-xs text-slate-400 mt-2.5 line-clamp-2 leading-relaxed">
                  {gig.description}
                </p>

                {/* Skill tags */}
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {gig.requiredSkills.slice(0, 3).map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-900 text-amber-200 border border-amber-500/20"
                    >
                      {skill}
                    </span>
                  ))}
                  {gig.requiredSkills.length > 3 && (
                    <span className="text-[11px] font-medium px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                      +{gig.requiredSkills.length - 3}
                    </span>
                  )}
                </div>
              </div>

              {/* Card Footer */}
              <div className="mt-5 pt-4 border-t border-amber-500/15 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-400/70" />
                    <span>{gig.workType}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400/70" />
                    <span>{gig.duration}</span>
                  </span>
                </div>

                <button
                  onClick={() => handleGigClick(gig)}
                  className="font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                >
                  <span>Apply</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Popular Skills Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-2 mb-8">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Top In-Demand Disciplines
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Popular Skills for College Gigs
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Whether coding APIs or designing visual branding, high-paying freelance gigs are waiting.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {POPULAR_SKILLS.map((skill, idx) => (
            <button
              key={idx}
              onClick={() => {
                setActiveTab('find-gigs');
              }}
              className="p-4 rounded-xl bg-[#0e131f] border border-amber-500/20 hover:border-amber-400/50 hover:shadow-lg transition-all text-left group flex items-start justify-between"
            >
              <div>
                <div className="mb-2 group-hover:scale-110 transition-transform">
                  {getSkillIcon(skill.icon)}
                </div>
                <p className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                  {skill.name}
                </p>
                <p className="text-[11px] text-amber-200/70 mt-0.5">{skill.count}</p>
              </div>
              <span className="text-[10px] uppercase font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/25">
                {skill.category}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* 6. About Section */}
      <section id="about-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="bg-gradient-to-r from-[#0d121c] via-[#121926] to-[#0d121c] border border-amber-500/30 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
          <div className="relative z-10 max-w-3xl space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              About GigConnect & The Mission
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight">
              Bridging the Gap Between Classroom Theory and Real-World Industry Execution
            </h2>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Traditional internships often involve rigid schedules, long unpaid trial periods, or bureaucratic recruitment cycles. GigConnect re-imagines campus freelancing by structuring work into bite-sized, high-impact sprints that respect academic exams while providing businesses with fast, agile execution.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 text-xs">
              <div className="p-4 rounded-xl bg-black/40 border border-amber-500/20 backdrop-blur">
                <p className="font-bold text-amber-300 mb-1">For Students</p>
                <p className="text-slate-400 leading-relaxed">
                  Earn competitive rates, build a demonstrable portfolio of live client projects, and gain real client management skills before graduating.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-black/40 border border-amber-500/20 backdrop-blur">
                <p className="font-bold text-amber-300 mb-1">For Businesses</p>
                <p className="text-slate-400 leading-relaxed">
                  Access enthusiastic, tech-fluent digital natives without inflated agency retainers or full-time hiring commitments.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Final Call to Action */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6 pt-4">
        <div className="p-10 rounded-3xl bg-[#0e131f] border border-amber-500/30 shadow-2xl space-y-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <span className="text-xs font-bold text-amber-400 tracking-wider uppercase">
            Join 1,450+ Campus Freelancers & Founders
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Ready to monetize your skills or post your first gig?
          </h2>
          <p className="text-sm text-slate-300 max-w-xl mx-auto">
            Get started for free today. No credit card required. Connect with students and businesses in minutes.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 relative z-10">
            <button
              onClick={() => openAuthModal('register', 'student')}
              className="w-full sm:w-auto px-7 py-3 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 rounded-xl hover:from-amber-300 hover:to-yellow-300 shadow-md shadow-amber-500/20 transition-all hover:scale-102"
            >
              Sign Up as Student Freelancer
            </button>
            <button
              onClick={() => openAuthModal('register', 'business')}
              className="w-full sm:w-auto px-7 py-3 text-xs font-bold text-amber-300 bg-[#121824] border border-amber-500/35 rounded-xl hover:bg-[#182133] transition-all"
            >
              Register as Business Client
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
