import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Bell, CheckCheck, Sparkles, FileText, MessageSquare, AlertCircle, ArrowRight } from 'lucide-react';

export const NotificationDrawer: React.FC = () => {
  const {
    notificationsOpen,
    setNotificationsOpen,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    setActiveTab,
    role
  } = useApp();

  if (!notificationsOpen) return null;

  // Filter for role or all
  const relevantNotifications = notifications.filter(
    n => n.role === 'all' || n.role === role || role === 'guest'
  );

  const unreadCount = relevantNotifications.filter(n => !n.read).length;

  const handleNotificationClick = (notifId: string, linkTab?: string) => {
    markNotificationRead(notifId);
    if (linkTab) {
      setActiveTab(linkTab);
      setNotificationsOpen(false);
    }
  };

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'gig':
        return <Sparkles className="w-4 h-4 text-emerald-600" />;
      case 'application':
        return <FileText className="w-4 h-4 text-indigo-600" />;
      case 'message':
        return <MessageSquare className="w-4 h-4 text-blue-600" />;
      default:
        return <AlertCircle className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl border-l border-slate-200 flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">Notifications</h3>
            {unreadCount > 0 && (
              <span className="text-[10px] font-bold text-white bg-indigo-600 px-1.5 py-0.2 rounded-full">
                {unreadCount}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={markAllNotificationsRead}
                className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark all read</span>
              </button>
            )}
            <button
              onClick={() => setNotificationsOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-4 overflow-y-auto flex-1 divide-y divide-slate-100 space-y-1">
          {relevantNotifications.length > 0 ? (
            relevantNotifications.map(n => (
              <div
                key={n.id}
                onClick={() => handleNotificationClick(n.id, n.linkTab)}
                className={`p-3.5 rounded-xl cursor-pointer transition-colors flex items-start gap-3 ${
                  n.read ? 'hover:bg-slate-50 opacity-80' : 'bg-indigo-50/40 hover:bg-indigo-50/70 border border-indigo-100'
                }`}
              >
                <div className="p-2 rounded-lg bg-white shadow-xs border border-slate-100 shrink-0">
                  {getNotifIcon(n.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <p className={`text-xs font-bold leading-tight ${n.read ? 'text-slate-800' : 'text-indigo-950'}`}>
                      {n.title}
                    </p>
                    <span className="text-[10px] text-slate-400 whitespace-nowrap font-mono">{n.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                    {n.message}
                  </p>
                  {n.linkTab && (
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-indigo-600 mt-1 hover:underline">
                      <span>View details</span>
                      <ArrowRight className="w-2.5 h-2.5" />
                    </span>
                  )}
                </div>

                {!n.read && (
                  <span className="w-2 h-2 rounded-full bg-indigo-600 shrink-0 mt-1.5" />
                )}
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-400 space-y-2">
              <Bell className="w-8 h-8 mx-auto text-slate-300" />
              <p className="text-xs">No notifications yet</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 text-center">
          <p className="text-[11px] text-slate-500">
            Real-time alerts for gig recommendations, applications & messages
          </p>
        </div>
      </div>
    </div>
  );
};
