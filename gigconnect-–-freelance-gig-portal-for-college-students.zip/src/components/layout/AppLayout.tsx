import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  Search,
  FileCheck,
  Bookmark,
  User,
  Bell,
  Settings,
  LogOut,
  Briefcase,
  PlusCircle,
  Users,
  MessageSquare,
  Sparkles,
  Building2,
  Sliders
} from 'lucide-react';

interface AppLayoutProps {
  children: React.ReactNode;
}

export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const {
    role,
    activeTab,
    setActiveTab,
    currentStudent,
    currentBusiness,
    notifications,
    setNotificationsOpen,
    setMessagesOpen,
    setPostGigModalOpen,
    logout
  } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;

  if (role === 'guest') {
    return <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">{children}</main>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Desktop Sidebar (3 cols) */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-24">
          <div className="bg-[#0e131f] rounded-2xl border border-amber-500/25 shadow-2xl p-4 space-y-6">
            {/* User mini profile card */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#141b2a] border border-amber-500/20">
              <img
                src={role === 'student' ? currentStudent.avatar : currentBusiness.avatar}
                alt="Avatar"
                className="w-10 h-10 rounded-xl bg-slate-900 border border-amber-500/30 object-cover"
              />
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">
                  {role === 'student' ? currentStudent.name : currentBusiness.companyName}
                </p>
                <p className="text-[11px] text-amber-300/70 truncate">
                  {role === 'student' ? currentStudent.college : currentBusiness.organizationType}
                </p>
              </div>
            </div>

            {/* Navigation Links */}
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-amber-400/80 px-3 tracking-wider block mb-1">
                Navigation
              </span>

              {role === 'student' ? (
                <>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'dashboard'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    <span>Dashboard</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('find-gigs')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'find-gigs'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <Search className="w-4 h-4" />
                    <span>Find Gigs</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('my-applications')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'my-applications'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <FileCheck className="w-4 h-4" />
                    <span>My Applications</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('saved-gigs')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'saved-gigs'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <Bookmark className="w-4 h-4" />
                    <span>Saved Gigs</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('profile')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'profile'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <User className="w-4 h-4" />
                    <span>My Profile</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'dashboard'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    <span>Dashboard</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('my-gigs')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'my-gigs'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <Briefcase className="w-4 h-4" />
                    <span>My Gigs</span>
                  </button>

                  <button
                    onClick={() => setPostGigModalOpen(true)}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition-colors shadow-sm"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>Post a Gig</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('applications')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'applications'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <FileCheck className="w-4 h-4" />
                    <span>Applications</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('find-students')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'find-students'
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'text-slate-300 hover:bg-slate-900 hover:text-amber-400'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span>Find Students</span>
                  </button>
                </>
              )}
            </div>

            {/* Quick Actions / System */}
            <div className="pt-2 border-t border-amber-500/15 space-y-1">
              <span className="text-[10px] uppercase font-bold text-amber-400/80 px-3 tracking-wider block mb-1">
                Workspace Tools
              </span>

              <button
                onClick={() => setNotificationsOpen(true)}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-900 hover:text-amber-400 transition-colors"
              >
                <span className="flex items-center gap-2.5">
                  <Bell className="w-4 h-4" />
                  <span>Notifications</span>
                </span>
                {unreadCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                    {unreadCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setMessagesOpen(true)}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-900 hover:text-amber-400 transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Messages</span>
              </button>

              <button
                onClick={() => {
                  if (role === 'student') setActiveTab('profile');
                  else setActiveTab('dashboard');
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-900 hover:text-amber-400 transition-colors"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>

              <button
                onClick={logout}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-950/40 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content Area (9 cols on desktop) */}
        <main className="lg:col-span-9">{children}</main>
      </div>
    </div>
  );
};
