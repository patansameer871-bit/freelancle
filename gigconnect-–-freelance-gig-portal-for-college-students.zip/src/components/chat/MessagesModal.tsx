import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Send, MessageSquare, Building2, User, Sparkles } from 'lucide-react';

export const MessagesModal: React.FC = () => {
  const {
    messagesOpen,
    setMessagesOpen,
    messages,
    sendChatMessage,
    role,
    currentStudent,
    currentBusiness
  } = useApp();

  const [input, setInput] = useState('');

  if (!messagesOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    sendChatMessage(input);
    setInput('');
  };

  const isStudent = role === 'student';
  const partnerName = isStudent ? currentBusiness.name : currentStudent.name;
  const partnerSubtitle = isStudent ? currentBusiness.companyName : currentStudent.college;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden h-[540px] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
              {isStudent ? <Building2 className="w-4 h-4" /> : <User className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-slate-900">{partnerName}</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-500" title="Online" />
              </div>
              <p className="text-[11px] text-slate-500">{partnerSubtitle}</p>
            </div>
          </div>

          <button
            onClick={() => setMessagesOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Gig Context Pill */}
        <div className="bg-indigo-50/70 border-b border-indigo-100 px-6 py-2 flex items-center justify-between text-xs">
          <span className="text-indigo-900 font-medium truncate">
            Project: <strong>Build a College Event Website (Genesis Hack 2026)</strong>
          </span>
          <span className="text-emerald-700 font-mono text-[11px] font-bold">Escrow Active</span>
        </div>

        {/* Message Thread */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 bg-slate-50/40">
          {messages.map(msg => {
            const isMe = msg.senderRole === role;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <span className="text-[10px] text-slate-400 mb-1 px-1">
                  {msg.senderName} · {msg.timestamp}
                </span>
                <div
                  className={`max-w-md p-3.5 rounded-2xl text-xs leading-relaxed shadow-xs ${
                    isMe
                      ? 'bg-indigo-600 text-white rounded-br-xs'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Input Footer */}
        <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-100 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder={`Message ${partnerName.split(' ')[0]} about project milestones...`}
            className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50"
          />
          <button
            type="submit"
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
