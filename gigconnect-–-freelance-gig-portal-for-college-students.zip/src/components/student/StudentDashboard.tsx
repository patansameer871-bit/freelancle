import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  TrendingUp,
  Clock,
  CheckCircle2,
  FileCheck,
  Bookmark,
  ArrowRight,
  MapPin,
  Calendar,
  Building2,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { Gig } from '../../types';

export const StudentDashboard: React.FC = () => {
  const {
    currentStudent,
    gigs,
    applications,
    setActiveTab,
    openApplyModal,
    setSelectedGigId,
    toggleSaveGig,
    isGigSaved,
    calculateMatchScore
  } = useApp();

  // Statistics calculation
  const studentApps = applications.filter(a => a.studentId === currentStudent.id);
  const totalApps = studentApps.length;
  const pendingApps = studentApps.filter(a => a.status === 'Pending' || a.status === 'Under Review').length;
  const acceptedApps = studentApps.filter(a => a.status === 'Accepted' || a.status === 'In Progress').length;
  const completedApps = studentApps.filter(a => a.status === 'Completed').length;

  // Profile completion calculation
  const calculateProfileCompletion = () => {
    let score = 0;
    if (currentStudent.name) score += 15;
    if (currentStudent.college) score += 15;
    if (currentStudent.course) score += 10;
    if (currentStudent.skills.length >= 3) score += 20;
    if (currentStudent.bio) score += 15;
    if (currentStudent.portfolio.length >= 1) score += 15;
    if (currentStudent.resumeName) score += 10;
    return score;
  };

  const profileScore = calculateProfileCompletion();

  // Recommended gigs sorted by match score
  const recommendedGigs = gigs
    .map(gig => ({
      ...gig,
      matchScore: calculateMatchScore(gig.requiredSkills, currentStudent.skills)
    }))
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 3);

  // New gigs (latest 3)
  const newGigs = [...gigs].sort((a, b) => b.id.localeCompare(a.id)).slice(0, 3);

  const handleGigDetails = (gig: Gig) => {
    setSelectedGigId(gig.id);
    setActiveTab('find-gigs');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* 1. Welcome & Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-indigo-800 to-purple-800 rounded-2xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-medium text-indigo-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Campus Freelance Hub</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {currentStudent.name.split(' ')[0]}! 🚀
            </h1>
            <p className="text-xs sm:text-sm text-indigo-100 leading-relaxed">
              {currentStudent.college} · {currentStudent.course}
            </p>
            <p className="text-xs text-indigo-200/90 pt-1">
              There are <span className="font-bold text-white font-mono">{gigs.length} active gigs</span> matching your technical and creative skill set.
            </p>
          </div>

          {/* Profile Completion Widget */}
          <div className="bg-white/10 backdrop-blur border border-white/15 rounded-xl p-4 min-w-[260px] text-white">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold">Profile Strength</span>
              <span className="text-xs font-bold font-mono tabular-nums text-amber-300">{profileScore}%</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2 overflow-hidden mb-3">
              <div
                className="bg-gradient-to-r from-amber-400 to-emerald-400 h-2 rounded-full transition-all duration-500"
                style={{ width: `${profileScore}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-indigo-200">
              <span>{profileScore === 100 ? 'All milestones complete!' : 'Add 1 more project for 100%'}</span>
              <button
                onClick={() => setActiveTab('profile')}
                className="underline hover:text-white font-medium ml-2"
              >
                Edit Profile
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Card 1: Total Applications */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Total Applications</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <FileCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {totalApps}
          </p>
          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span>Sent across {gigs.length} businesses</span>
          </p>
        </div>

        {/* Card 2: Pending */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-amber-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Pending Review</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {pendingApps}
          </p>
          <p className="text-[11px] text-amber-600 font-medium mt-1">
            Under hiring manager review
          </p>
        </div>

        {/* Card 3: Accepted */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Accepted / Active</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {acceptedApps}
          </p>
          <p className="text-[11px] text-emerald-600 font-medium mt-1">
            Active milestones in progress
          </p>
        </div>

        {/* Card 4: Completed */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-purple-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Completed Gigs</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {completedApps}
          </p>
          <p className="text-[11px] text-purple-600 font-medium mt-1">
            Total Earned: ₹{currentStudent.totalEarnings.toLocaleString()}
          </p>
        </div>
      </div>

      {/* 3. Recommended Gigs Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Recommended Gigs for You</h2>
            <p className="text-xs text-slate-500">Ranked by your profile skills & course specializations</p>
          </div>
          <button
            onClick={() => setActiveTab('find-gigs')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>Explore All</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {recommendedGigs.map(gig => {
            const saved = isGigSaved(gig.id);
            const applied = applications.some(a => a.gigId === gig.id && a.studentId === currentStudent.id);

            return (
              <div
                key={gig.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>{gig.matchScore}% Match</span>
                    </span>
                    <button
                      onClick={() => toggleSaveGig(gig.id)}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        saved
                          ? 'bg-indigo-50 border-indigo-200 text-indigo-600'
                          : 'border-slate-200 text-slate-400 hover:text-slate-600'
                      }`}
                      title={saved ? 'Remove bookmark' : 'Bookmark gig'}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-indigo-600' : ''}`} />
                    </button>
                  </div>

                  <h3
                    onClick={() => handleGigDetails(gig)}
                    className="text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer line-clamp-1 transition-colors"
                  >
                    {gig.title}
                  </h3>

                  <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-slate-400" />
                    <span>{gig.businessName}</span>
                  </p>

                  <div className="mt-3 flex flex-wrap gap-1">
                    {gig.requiredSkills.map((skill, sIdx) => (
                      <span
                        key={sIdx}
                        className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Budget</span>
                      <span className="font-bold text-slate-900 font-mono">
                        ₹{gig.minBudget.toLocaleString()} - ₹{gig.maxBudget.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Duration / Mode</span>
                      <span className="font-medium text-slate-800 truncate block">
                        {gig.duration} · {gig.workType}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => handleGigDetails(gig)}
                    className="flex-1 py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    View Details
                  </button>
                  {applied ? (
                    <span className="py-1.5 px-3 rounded-lg bg-slate-100 text-xs font-semibold text-slate-500">
                      Applied
                    </span>
                  ) : (
                    <button
                      onClick={() => openApplyModal(gig)}
                      className="flex-1 py-1.5 px-3 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors shadow-sm"
                    >
                      Apply Now
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. New Gigs Feed */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Recently Posted Gigs</h2>
            <p className="text-xs text-slate-500">Fresh listings posted within the last 48 hours</p>
          </div>
          <button
            onClick={() => setActiveTab('find-gigs')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            Browse All ({gigs.length})
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-sm">
          {newGigs.map(gig => (
            <div
              key={gig.id}
              className="p-4 sm:p-5 hover:bg-slate-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                    {gig.category}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-500">Posted on {gig.postedDate}</span>
                </div>
                <h3
                  onClick={() => handleGigDetails(gig)}
                  className="text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors"
                >
                  {gig.title}
                </h3>
                <p className="text-xs text-slate-500 flex items-center gap-2">
                  <span>{gig.businessName}</span>
                  <span>·</span>
                  <span>{gig.location}</span>
                  <span>·</span>
                  <span>{gig.experienceLevel}</span>
                </p>
              </div>

              <div className="flex items-center gap-3 sm:self-center">
                <div className="text-right sm:pr-3">
                  <span className="text-sm font-bold text-slate-900 font-mono">
                    ₹{gig.maxBudget.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-normal">Fixed Budget</span>
                </div>
                <button
                  onClick={() => handleGigDetails(gig)}
                  className="px-3.5 py-1.5 rounded-lg border border-indigo-200 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 transition-colors"
                >
                  Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
