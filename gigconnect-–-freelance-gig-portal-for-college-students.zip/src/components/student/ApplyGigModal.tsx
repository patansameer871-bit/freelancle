import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, CheckCircle2, DollarSign, Send, AlertCircle, FileText, Link as LinkIcon } from 'lucide-react';
import { Gig } from '../../types';

export const ApplyGigModal: React.FC = () => {
  const { applyModalGig, closeApplyModal, applyToGig, currentStudent } = useApp();

  const [proposedBudget, setProposedBudget] = useState<number>(
    applyModalGig ? applyModalGig.maxBudget : 10000
  );
  const [coverNote, setCoverNote] = useState<string>('');
  const [portfolioLink, setPortfolioLink] = useState<string>(
    currentStudent.portfolio[0]?.link || ''
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string>('');

  if (!applyModalGig) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!coverNote.trim()) {
      setError('Please provide a brief pitch or cover note explaining why you are a great fit.');
      return;
    }
    if (proposedBudget <= 0) {
      setError('Please enter a valid proposed budget.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const success = applyToGig(
        applyModalGig.id,
        coverNote,
        proposedBudget,
        portfolioLink ? [portfolioLink] : []
      );
      setIsSubmitting(false);
      if (!success) {
        setError('Failed to submit application. You may have already applied.');
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-start justify-between bg-slate-50">
          <div>
            <span className="text-[11px] font-semibold text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
              Application Submission
            </span>
            <h3 className="text-base font-bold text-slate-900 mt-1">
              Apply for: {applyModalGig.title}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Client: <span className="font-semibold text-slate-700">{applyModalGig.businessName}</span> ({applyModalGig.location})
            </p>
          </div>
          <button
            onClick={closeApplyModal}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-2 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Quick Summary Banner */}
          <div className="p-3 rounded-xl bg-indigo-50/50 border border-indigo-100 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500 block text-[10px]">Client Budget Range</span>
              <span className="font-bold text-slate-900 font-mono">
                ₹{applyModalGig.minBudget.toLocaleString()} - ₹{applyModalGig.maxBudget.toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Duration</span>
              <span className="font-bold text-slate-900">{applyModalGig.duration}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Applicant Profile</span>
              <span className="font-bold text-indigo-700">{currentStudent.name}</span>
            </div>
          </div>

          {/* Proposed Budget */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Your Proposed Fee (₹) *
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 text-xs font-mono">
                ₹
              </span>
              <input
                type="number"
                value={proposedBudget}
                onChange={e => setProposedBudget(Number(e.target.value))}
                min={1000}
                max={100000}
                className="w-full pl-7 pr-3 py-2 text-xs font-mono rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="e.g. 12000"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              Competitive proposals staying within client range have 3x higher acceptance.
            </p>
          </div>

          {/* Cover Pitch */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Cover Pitch / Why are you right for this gig? *
            </label>
            <textarea
              rows={4}
              value={coverNote}
              onChange={e => setCoverNote(e.target.value)}
              placeholder="Detail your relevant experience, similar projects you built at college, and when you can start..."
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>Mention tech stack, delivery speed, or links to similar code.</span>
              <button
                type="button"
                onClick={() =>
                  setCoverNote(
                    `Hi ${applyModalGig.businessName} team! I have deep hands-on expertise with ${applyModalGig.requiredSkills.join(', ')}. Recently built production-ready projects for my university and can deliver this within ${applyModalGig.duration} with clean, documented code!`
                  )
                }
                className="text-indigo-600 hover:underline font-medium"
              >
                Insert sample pitch
              </button>
            </div>
          </div>

          {/* Portfolio link */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Relevant Project or GitHub / Behance Link
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <LinkIcon className="w-3.5 h-3.5" />
              </span>
              <input
                type="url"
                value={portfolioLink}
                onChange={e => setPortfolioLink(e.target.value)}
                placeholder="https://github.com/your-username/sample-project"
                className="w-full pl-8 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Escrow assurance note */}
          <div className="p-3 rounded-lg bg-emerald-50/60 border border-emerald-100 flex items-start gap-2 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong>GigConnect Student Protection:</strong> Once accepted, the client funds project escrow before you commence work. Payout is guaranteed upon milestone delivery.
            </p>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={closeApplyModal}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Application'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
