import React from 'react';
import { useApp } from '../../context/AppContext';
import { Bookmark, Building2, MapPin, Clock, ArrowRight, Sparkles, Trash2 } from 'lucide-react';

export const SavedGigs: React.FC = () => {
  const {
    gigs,
    savedGigIds,
    toggleSaveGig,
    setSelectedGigId,
    openApplyModal,
    setActiveTab,
    calculateMatchScore,
    currentStudent
  } = useApp();

  const savedGigs = gigs.filter(g => savedGigIds.includes(g.id));

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Bookmarked & Saved Gigs
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Keep track of gigs you want to research or prepare custom proposals for.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('find-gigs')}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white transition-all shadow-sm"
        >
          Discover More Gigs
        </button>
      </div>

      {savedGigs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedGigs.map(gig => {
            const match = calculateMatchScore(gig.requiredSkills, currentStudent.skills);

            return (
              <div
                key={gig.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>{match}% Match</span>
                    </span>
                    <button
                      onClick={() => toggleSaveGig(gig.id)}
                      className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                      title="Remove bookmark"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <h3
                    onClick={() => setSelectedGigId(gig.id)}
                    className="text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors"
                  >
                    {gig.title}
                  </h3>

                  <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-slate-400" />
                    <span>{gig.businessName}</span>
                  </p>

                  <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                    {gig.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-slate-900">
                      ₹{gig.maxBudget.toLocaleString()}
                    </span>
                    <span className="text-slate-500 font-sans text-[11px]">{gig.duration}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => setSelectedGigId(gig.id)}
                    className="flex-1 py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    Details
                  </button>
                  <button
                    onClick={() => openApplyModal(gig)}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700"
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Bookmark className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No saved gigs yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Click the bookmark icon on any gig card in the discovery page to save it here for quick access.
          </p>
          <button
            onClick={() => setActiveTab('find-gigs')}
            className="px-4 py-2 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors"
          >
            Browse Gigs
          </button>
        </div>
      )}
    </div>
  );
};
