import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  GraduationCap,
  MapPin,
  Clock,
  Mail,
  Phone,
  Github,
  Linkedin,
  FileText,
  Upload,
  Edit3,
  ExternalLink,
  Plus,
  Trash2,
  CheckCircle2,
  Star,
  Award,
  Sparkles,
  X
} from 'lucide-react';
import { PortfolioProject } from '../../types';

export const StudentProfile: React.FC = () => {
  const { currentStudent, updateStudentProfile } = useApp();
  const [isEditing, setIsEditing] = useState(false);

  // Edit form state
  const [formData, setFormData] = useState({
    name: currentStudent.name,
    college: currentStudent.college,
    course: currentStudent.course,
    graduationYear: currentStudent.graduationYear,
    location: currentStudent.location,
    bio: currentStudent.bio,
    hourlyRate: currentStudent.hourlyRate,
    availability: currentStudent.availability,
    phone: currentStudent.phone,
    github: currentStudent.github,
    linkedin: currentStudent.linkedin,
    skillsInput: currentStudent.skills.join(', '),
    resumeName: currentStudent.resumeName
  });

  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    link: '',
    tags: 'React, Node.js'
  });

  const [isAddingProject, setIsAddingProject] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const skillsArray = formData.skillsInput
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    updateStudentProfile({
      name: formData.name,
      college: formData.college,
      course: formData.course,
      graduationYear: Number(formData.graduationYear),
      location: formData.location,
      bio: formData.bio,
      hourlyRate: formData.hourlyRate,
      availability: formData.availability as any,
      phone: formData.phone,
      github: formData.github,
      linkedin: formData.linkedin,
      skills: skillsArray.length ? skillsArray : currentStudent.skills,
      resumeName: formData.resumeName
    });

    setIsEditing(false);
  };

  const handleAddProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProject.title.trim()) return;

    const project: PortfolioProject = {
      id: 'proj-' + Date.now(),
      title: newProject.title,
      description: newProject.description,
      link: newProject.link || 'https://github.com/project',
      tags: newProject.tags.split(',').map(t => t.trim()).filter(Boolean)
    };

    updateStudentProfile({
      portfolio: [project, ...currentStudent.portfolio]
    });

    setNewProject({ title: '', description: '', link: '', tags: 'React, Node.js' });
    setIsAddingProject(false);
  };

  const handleDeleteProject = (projId: string) => {
    updateStudentProfile({
      portfolio: currentStudent.portfolio.filter(p => p.id !== projId)
    });
  };

  const handleSimulatedResumeUpload = () => {
    const fakeFileName = `Aarav_Sharma_Resume_${new Date().getFullYear()}_Updated.pdf`;
    updateStudentProfile({
      resumeName: fakeFileName
    });
    setFormData(prev => ({ ...prev, resumeName: fakeFileName }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner & Main Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Cover graphic */}
        <div className="h-32 sm:h-40 bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 relative">
          <div className="absolute top-4 right-4">
            <button
              onClick={() => setIsEditing(true)}
              className="px-3.5 py-1.5 rounded-lg bg-white/90 hover:bg-white text-slate-800 text-xs font-semibold shadow-sm transition-all flex items-center gap-1.5"
            >
              <Edit3 className="w-3.5 h-3.5 text-indigo-600" />
              <span>Edit Profile</span>
            </button>
          </div>
        </div>

        {/* Profile Details Container */}
        <div className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-16 sm:-mt-14 mb-4">
            {/* Avatar */}
            <div className="relative inline-block">
              <img
                src={currentStudent.avatar}
                alt={currentStudent.name}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl border-4 border-white shadow-md bg-white object-cover"
              />
              <span className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold" title="Verified Campus Student">
                ✓
              </span>
            </div>

            {/* Quick stats badges */}
            <div className="flex flex-wrap gap-2 text-xs">
              <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Client Rating</span>
                <span className="font-bold text-slate-900 font-mono flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  <span>{currentStudent.rating} / 5.0</span>
                </span>
              </div>

              <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Completed</span>
                <span className="font-bold text-slate-900 font-mono">
                  {currentStudent.completedGigsCount} Gigs
                </span>
              </div>

              <div className="px-3 py-1.5 rounded-xl bg-indigo-50 border border-indigo-100">
                <span className="text-[10px] text-indigo-500 block uppercase font-bold">Total Earned</span>
                <span className="font-bold text-indigo-700 font-mono">
                  ₹{currentStudent.totalEarnings.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Name & Academic Credentials */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                {currentStudent.name}
              </h1>
              <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
                Student Freelancer
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
              <span className="flex items-center gap-1.5 font-medium text-slate-800">
                <GraduationCap className="w-4 h-4 text-indigo-600" />
                <span>{currentStudent.college}</span>
              </span>
              <span>·</span>
              <span>{currentStudent.course} (Class of {currentStudent.graduationYear})</span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{currentStudent.location}</span>
              </span>
            </div>

            {/* Availability & Rate */}
            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
                <Clock className="w-3 h-3 text-emerald-600" />
                <span>Availability: {currentStudent.availability}</span>
              </span>
              <span className="text-slate-600">
                Target Rate: <strong className="text-slate-900 font-mono">{currentStudent.hourlyRate}</strong>
              </span>
            </div>
          </div>

          {/* Bio */}
          <div className="mt-5 pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              About Me & Experience
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-4xl">
              {currentStudent.bio}
            </p>
          </div>

          {/* Contact / Social links */}
          <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-4 text-xs text-slate-600">
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              <span>{currentStudent.email}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>{currentStudent.phone}</span>
            </span>
            {currentStudent.github && (
              <a
                href={currentStudent.github}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-indigo-600 hover:underline"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GitHub Profile</span>
              </a>
            )}
            {currentStudent.linkedin && (
              <a
                href={currentStudent.linkedin}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-indigo-600 hover:underline"
              >
                <Linkedin className="w-3.5 h-3.5" />
                <span>LinkedIn</span>
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Two Column Grid: Left Skills & Resume, Right Portfolio Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): Skills & Resume */}
        <div className="lg:col-span-5 space-y-6">
          {/* Skills Section */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Technical & Creative Skills</h3>
              <button
                onClick={() => setIsEditing(true)}
                className="text-xs font-semibold text-indigo-600 hover:underline"
              >
                + Add Skill
              </button>
            </div>
            <p className="text-xs text-slate-500">
              Verified skills used for automated gig matching algorithms.
            </p>

            <div className="flex flex-wrap gap-2 pt-2">
              {currentStudent.skills.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/80 shadow-xs flex items-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3 text-indigo-500" />
                  <span>{skill}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Resume Upload / Document Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Resume / CV</h3>
            <p className="text-xs text-slate-500">
              Your resume is automatically attached when you apply for verified client gigs.
            </p>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center font-bold text-xs">
                  PDF
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900 truncate max-w-[180px]">
                    {currentStudent.resumeName}
                  </p>
                  <p className="text-[10px] text-slate-500">Verified · ATS Readable · 142 KB</p>
                </div>
              </div>

              <button
                onClick={handleSimulatedResumeUpload}
                className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors flex items-center gap-1"
                title="Simulate uploading a new resume"
              >
                <Upload className="w-3 h-3" />
                <span>Upload New</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Portfolio & Projects */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Portfolio & Campus Projects</h3>
                <p className="text-xs text-slate-500">Showcase your live deployments and code</p>
              </div>

              <button
                onClick={() => setIsAddingProject(!isAddingProject)}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Project</span>
              </button>
            </div>

            {/* Add Project Form Drawer */}
            {isAddingProject && (
              <form
                onSubmit={handleAddProject}
                className="p-4 rounded-xl bg-slate-50 border border-indigo-200 space-y-3"
              >
                <h4 className="text-xs font-bold text-indigo-900">Add New Showcase Project</h4>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Project Title *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Smart Campus Delivery App"
                    value={newProject.title}
                    onChange={e => setNewProject({ ...newProject, title: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Description
                  </label>
                  <textarea
                    rows={2}
                    placeholder="What did you build and what impact did it make?"
                    value={newProject.description}
                    onChange={e => setNewProject({ ...newProject, description: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Live URL or GitHub
                    </label>
                    <input
                      type="text"
                      placeholder="https://..."
                      value={newProject.link}
                      onChange={e => setNewProject({ ...newProject, link: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Tags (comma separated)
                    </label>
                    <input
                      type="text"
                      placeholder="React, Tailwind, Node.js"
                      value={newProject.tags}
                      onChange={e => setNewProject({ ...newProject, tags: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingProject(false)}
                    className="px-3 py-1 text-xs text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
                  >
                    Save Project
                  </button>
                </div>
              </form>
            )}

            {/* Projects List */}
            <div className="space-y-4">
              {currentStudent.portfolio.map(proj => (
                <div
                  key={proj.id}
                  className="p-4 rounded-xl border border-slate-200 hover:border-indigo-200 hover:bg-slate-50/50 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-sm font-bold text-slate-900">{proj.title}</h4>
                      <div className="flex items-center gap-1.5">
                        <a
                          href={proj.link}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1 text-slate-400 hover:text-indigo-600"
                          title="Open live link"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                        <button
                          onClick={() => handleDeleteProject(proj.id)}
                          className="p-1 text-slate-400 hover:text-rose-500"
                          title="Delete project"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {proj.description}
                    </p>

                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {proj.tags.map((tag, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Full Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">Edit Student Profile</h3>
              <button
                onClick={() => setIsEditing(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="p-6 overflow-y-auto space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    College / University *
                  </label>
                  <input
                    type="text"
                    value={formData.college}
                    onChange={e => setFormData({ ...formData, college: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Degree / Course
                  </label>
                  <input
                    type="text"
                    value={formData.course}
                    onChange={e => setFormData({ ...formData, course: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Graduation Year
                  </label>
                  <input
                    type="number"
                    value={formData.graduationYear}
                    onChange={e => setFormData({ ...formData, graduationYear: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Location
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={e => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Skills (comma separated)
                </label>
                <input
                  type="text"
                  value={formData.skillsInput}
                  onChange={e => setFormData({ ...formData, skillsInput: e.target.value })}
                  placeholder="Java, React, UI/UX, Python, Graphic Design, Video Editing"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  Adding skills automatically updates your match score across all active gigs!
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Weekly Availability
                  </label>
                  <select
                    value={formData.availability}
                    onChange={e => setFormData({ ...formData, availability: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white"
                  >
                    <option value="Immediate (15-20 hrs/wk)">Immediate (15-20 hrs/wk)</option>
                    <option value="Part-time (10 hrs/wk)">Part-time (10 hrs/wk)</option>
                    <option value="Weekends only">Weekends only</option>
                    <option value="Flexible">Flexible</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Hourly / Milestone Target
                  </label>
                  <input
                    type="text"
                    value={formData.hourlyRate}
                    onChange={e => setFormData({ ...formData, hourlyRate: e.target.value })}
                    placeholder="₹600/hr"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  About Me / Bio
                </label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={e => setFormData({ ...formData, bio: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    GitHub Profile Link
                  </label>
                  <input
                    type="url"
                    value={formData.github}
                    onChange={e => setFormData({ ...formData, github: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    LinkedIn Profile Link
                  </label>
                  <input
                    type="url"
                    value={formData.linkedin}
                    onChange={e => setFormData({ ...formData, linkedin: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm"
                >
                  Save Profile Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
