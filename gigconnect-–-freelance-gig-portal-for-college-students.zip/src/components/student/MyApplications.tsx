import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Building2,
  Calendar,
  MessageSquare,
  ExternalLink,
  ChevronRight,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { ApplicationStatus } from '../../types';

export const MyApplications: React.FC = () => {
  const { applications, currentStudent, setActiveTab, setMessagesOpen } = useApp();
  const [activeFilter, setActiveFilter] = useState<'All' | ApplicationStatus | 'Active'>('All');

  // Filter student's applications
  const studentApps = applications.filter(a => a.studentId === currentStudent.id);

  const filteredApps = studentApps.filter(app => {
    if (activeFilter === 'All') return true;
    if (activeFilter === 'Pending') return app.status === 'Pending' || app.status === 'Under Review';
    if (activeFilter === 'Accepted') return app.status === 'Accepted' || app.status === 'In Progress';
    return app.status === activeFilter;
  });

  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'Pending':
        return (
          <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-600" />
            <span>Pending</span>
          </span>
        );
      case 'Under Review':
        return (
          <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <Clock className="w-3 h-3 text-blue-600" />
            <span>Under Review</span>
          </span>
        );
      case 'Accepted':
        return (
          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>Accepted</span>
          </span>
        );
      case 'In Progress':
        return (
          <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-indigo-600" />
            <span>In Progress</span>
          </span>
        );
      case 'Completed':
        return (
          <span className="text-[11px] font-semibold text-purple-700 bg-purple-50 border border-purple-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-purple-600" />
            <span>Completed</span>
          </span>
        );
      case 'Rejected':
        return (
          <span className="text-[11px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <XCircle className="w-3 h-3 text-rose-600" />
            <span>Rejected</span>
          </span>
        );
    }
  };

  const STAGES: ApplicationStatus[] = ['Pending', 'Under Review', 'Accepted', 'In Progress', 'Completed'];

  const getStageIndex = (status: ApplicationStatus) => {
    if (status === 'Rejected') return -1;
    return STAGES.indexOf(status);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            My Applications & Hired Gigs
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Track your proposals, client reviews, milestone statuses, and released payments.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('find-gigs')}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white shadow-sm transition-all"
        >
          Explore More Gigs
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {(['All', 'Pending', 'Accepted', 'Completed', 'Rejected'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveFilter(tab)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              activeFilter === tab
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab === 'All'
              ? `All (${studentApps.length})`
              : tab === 'Pending'
              ? `Pending / Review (${studentApps.filter(a => a.status === 'Pending' || a.status === 'Under Review').length})`
              : tab === 'Accepted'
              ? `Accepted / Active (${studentApps.filter(a => a.status === 'Accepted' || a.status === 'In Progress').length})`
              : tab === 'Completed'
              ? `Completed (${studentApps.filter(a => a.status === 'Completed').length})`
              : `Rejected (${studentApps.filter(a => a.status === 'Rejected').length})`}
          </button>
        ))}
      </div>

      {/* Applications List */}
      {filteredApps.length > 0 ? (
        <div className="space-y-4">
          {filteredApps.map(app => {
            const currentStageIndex = getStageIndex(app.status);
            const isRejected = app.status === 'Rejected';

            return (
              <div
                key={app.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all space-y-5"
              >
                {/* Top Section */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      {getStatusBadge(app.status)}
                      <span className="text-slate-300">·</span>
                      <span className="text-xs text-slate-500 font-mono">
                        Applied on {app.appliedDate}
                      </span>
                    </div>

                    <h2 className="text-lg font-bold text-slate-900 hover:text-indigo-600 transition-colors">
                      {app.gigTitle}
                    </h2>

                    <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-semibold text-slate-700">{app.businessName}</span>
                    </p>
                  </div>

                  <div className="sm:text-right">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
                      Agreed / Proposed Budget
                    </span>
                    <span className="text-xl font-black text-slate-900 font-mono">
                      ₹{app.proposedBudget.toLocaleString()}
                    </span>
                    <button
                      onClick={() => setMessagesOpen(true)}
                      className="mt-2 text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 sm:justify-end"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Message Client</span>
                    </button>
                  </div>
                </div>

                {/* Cover Note & Pitch */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Your Pitch to {app.businessName}:
                  </span>
                  <p className="text-slate-700 leading-relaxed italic">
                    "{app.coverNote}"
                  </p>
                  {app.portfolioLinks && app.portfolioLinks.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center gap-2 text-[11px] text-indigo-600">
                      <span>Shared Links:</span>
                      {app.portfolioLinks.map((link, lIdx) => (
                        <a
                          key={lIdx}
                          href={link}
                          target="_blank"
                          rel="noreferrer"
                          className="hover:underline flex items-center gap-0.5 font-medium"
                        >
                          <span>{link.replace('https://', '')}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      ))}
                    </div>
                  )}
                </div>

                {/* Application Progress Timeline (Applied -> Under Review -> Accepted -> In Progress -> Completed) */}
                <div className="pt-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-3">
                    Application Milestone Timeline
                  </span>

                  {isRejected ? (
                    <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-2 text-xs text-rose-700">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>
                        The client opted for another profile with specialized requirements. Don't worry—explore new gigs posted daily!
                      </span>
                    </div>
                  ) : (
                    <div className="relative">
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                        {STAGES.map((stage, idx) => {
                          const isComplete = currentStageIndex >= idx;
                          const isCurrent = currentStageIndex === idx;

                          return (
                            <div
                              key={idx}
                              className={`p-2.5 rounded-xl border text-center transition-all ${
                                isCurrent
                                  ? 'bg-indigo-50 border-indigo-300 ring-2 ring-indigo-200/60'
                                  : isComplete
                                  ? 'bg-emerald-50/60 border-emerald-200'
                                  : 'bg-slate-50 border-slate-200 opacity-60'
                              }`}
                            >
                              <div className="flex items-center justify-center mb-1">
                                {isComplete ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                ) : (
                                  <span className="w-3.5 h-3.5 rounded-full border border-slate-300 flex items-center justify-center text-[9px] text-slate-400 font-mono">
                                    {idx + 1}
                                  </span>
                                )}
                              </div>
                              <p
                                className={`text-[11px] font-bold leading-tight ${
                                  isCurrent
                                    ? 'text-indigo-900'
                                    : isComplete
                                    ? 'text-emerald-900'
                                    : 'text-slate-500'
                                }`}
                              >
                                {stage}
                              </p>
                              {isCurrent && (
                                <span className="inline-block mt-1 text-[9px] font-semibold text-indigo-700 bg-indigo-100 px-1.5 py-0.2 rounded">
                                  Current Status
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Client Feedback (if completed or feedback given) */}
                {app.clientFeedback && (
                  <div className="p-3.5 rounded-xl bg-purple-50/70 border border-purple-100 flex items-start gap-2.5 text-xs text-purple-900">
                    <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block">Client Testimonial & Review:</span>
                      <p className="mt-0.5 leading-relaxed">{app.clientFeedback}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No applications in this category</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            You haven't submitted any applications under this status yet. Browse active gigs to start landing opportunities.
          </p>
          <button
            onClick={() => setActiveTab('find-gigs')}
            className="px-4 py-2 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors"
          >
            Explore Active Gigs
          </button>
        </div>
      )}
    </div>
  );
};
