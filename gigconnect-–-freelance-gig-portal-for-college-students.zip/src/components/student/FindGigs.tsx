import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Filter,
  SlidersHorizontal,
  Bookmark,
  Building2,
  MapPin,
  Clock,
  Sparkles,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { Gig } from '../../types';

export const FindGigs: React.FC = () => {
  const {
    gigs,
    setSelectedGigId,
    openApplyModal,
    toggleSaveGig,
    isGigSaved,
    currentStudent,
    calculateMatchScore,
    applications,
    role,
    openAuthModal
  } = useApp();

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('All');
  const [selectedWorkType, setSelectedWorkType] = useState('All');
  const [selectedBudget, setSelectedBudget] = useState('All');
  const [selectedDuration, setSelectedDuration] = useState('All');
  const [sortBy, setSortBy] = useState<'best_match' | 'latest' | 'budget_desc' | 'budget_asc'>('best_match');

  // Available skills extracted from gigs
  const allSkills = useMemo(() => {
    const set = new Set<string>();
    gigs.forEach(g => g.requiredSkills.forEach(s => set.add(s)));
    return ['All', ...Array.from(set)];
  }, [gigs]);

  // Filtered and sorted gigs
  const filteredGigs = useMemo(() => {
    return gigs
      .map(gig => ({
        ...gig,
        matchScore: calculateMatchScore(gig.requiredSkills, currentStudent.skills)
      }))
      .filter(gig => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesTitle = gig.title.toLowerCase().includes(q);
          const matchesBusiness = gig.businessName.toLowerCase().includes(q);
          const matchesSkills = gig.requiredSkills.some(s => s.toLowerCase().includes(q));
          const matchesDesc = gig.description.toLowerCase().includes(q);
          if (!matchesTitle && !matchesBusiness && !matchesSkills && !matchesDesc) return false;
        }

        // Skill filter
        if (selectedSkill !== 'All') {
          if (!gig.requiredSkills.some(s => s.toLowerCase() === selectedSkill.toLowerCase())) {
            return false;
          }
        }

        // Work type filter
        if (selectedWorkType !== 'All') {
          if (gig.workType !== selectedWorkType) return false;
        }

        // Budget filter
        if (selectedBudget !== 'All') {
          if (selectedBudget === 'under_5k' && gig.maxBudget > 5000) return false;
          if (selectedBudget === '5k_10k' && (gig.maxBudget < 5000 || gig.maxBudget > 10000)) return false;
          if (selectedBudget === '10k_20k' && (gig.maxBudget < 10000 || gig.maxBudget > 20000)) return false;
          if (selectedBudget === 'above_20k' && gig.maxBudget < 20000) return false;
        }

        // Duration filter
        if (selectedDuration !== 'All') {
          if (selectedDuration === 'days' && !gig.duration.toLowerCase().includes('day') && !gig.duration.toLowerCase().includes('1 week')) return false;
          if (selectedDuration === 'weeks' && !gig.duration.toLowerCase().includes('week')) return false;
          if (selectedDuration === 'month' && !gig.duration.toLowerCase().includes('month')) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'best_match') return b.matchScore - a.matchScore;
        if (sortBy === 'latest') return b.postedDate.localeCompare(a.postedDate);
        if (sortBy === 'budget_desc') return b.maxBudget - a.maxBudget;
        if (sortBy === 'budget_asc') return a.minBudget - b.minBudget;
        return 0;
      });
  }, [
    gigs,
    searchQuery,
    selectedSkill,
    selectedWorkType,
    selectedBudget,
    selectedDuration,
    sortBy,
    currentStudent.skills,
    calculateMatchScore
  ]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedSkill('All');
    setSelectedWorkType('All');
    setSelectedBudget('All');
    setSelectedDuration('All');
    setSortBy('best_match');
  };

  const handleApplyClick = (gig: Gig) => {
    if (role === 'guest') {
      openAuthModal('login', 'student');
      return;
    }
    openApplyModal(gig);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Search Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Find College Freelance Gigs
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Discover verified short-term contracts tailored to student schedules and academic skills.
          </p>
        </div>

        {/* Search input */}
        <div className="relative">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search gigs by title or skill (e.g. React, Java API, Video Editing, Logo Design)..."
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-xs text-slate-400 hover:text-slate-600"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter controls row */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
          {/* Skill Filter */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Skill
            </label>
            <select
              value={selectedSkill}
              onChange={e => setSelectedSkill(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              {allSkills.map((s, idx) => (
                <option key={idx} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Work Mode */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Work Mode
            </label>
            <select
              value={selectedWorkType}
              onChange={e => setSelectedWorkType(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="All">All Locations</option>
              <option value="Remote">100% Remote</option>
              <option value="Hybrid">Hybrid</option>
              <option value="On-site">On-site</option>
            </select>
          </div>

          {/* Budget */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Budget Range
            </label>
            <select
              value={selectedBudget}
              onChange={e => setSelectedBudget(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="All">Any Budget</option>
              <option value="under_5k">Under ₹5,000</option>
              <option value="5k_10k">₹5,000 - ₹10,000</option>
              <option value="10k_20k">₹10,000 - ₹20,000</option>
              <option value="above_20k">Above ₹20,000</option>
            </select>
          </div>

          {/* Duration */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Duration
            </label>
            <select
              value={selectedDuration}
              onChange={e => setSelectedDuration(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="All">Any Duration</option>
              <option value="days">Under 10 Days</option>
              <option value="weeks">1 - 3 Weeks</option>
              <option value="month">1 Month+</option>
            </select>
          </div>

          {/* Sorting */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Sort By
            </label>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-medium text-indigo-700"
            >
              <option value="best_match">Best Match (%)</option>
              <option value="latest">Latest Posted</option>
              <option value="budget_desc">Budget: High to Low</option>
              <option value="budget_asc">Budget: Low to High</option>
            </select>
          </div>
        </div>

        {/* Results count & reset */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span>
            Showing <strong className="text-slate-900 font-mono">{filteredGigs.length}</strong> of{' '}
            <strong className="text-slate-900 font-mono">{gigs.length}</strong> available gigs
          </span>
          {(searchQuery || selectedSkill !== 'All' || selectedWorkType !== 'All' || selectedBudget !== 'All' || selectedDuration !== 'All') && (
            <button
              onClick={resetFilters}
              className="text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>
      </div>

      {/* Gig Cards Grid */}
      {filteredGigs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGigs.map(gig => {
            const saved = isGigSaved(gig.id);
            const applied = applications.some(
              a => a.gigId === gig.id && a.studentId === currentStudent.id
            );

            return (
              <div
                key={gig.id}
                className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-lg transition-all p-5 flex flex-col justify-between"
              >
                <div>
                  {/* Top Meta row */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-emerald-600" />
                        <span>{gig.matchScore}% Match</span>
                      </span>
                      <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {gig.category}
                      </span>
                    </div>

                    <button
                      onClick={() => toggleSaveGig(gig.id)}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        saved
                          ? 'bg-indigo-50 border-indigo-200 text-indigo-600'
                          : 'border-slate-200 text-slate-400 hover:text-slate-600'
                      }`}
                      title={saved ? 'Remove bookmark' : 'Bookmark gig'}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-indigo-600' : ''}`} />
                    </button>
                  </div>

                  {/* Title & Business */}
                  <h3
                    onClick={() => setSelectedGigId(gig.id)}
                    className="text-base font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors leading-snug"
                  >
                    {gig.title}
                  </h3>

                  <p className="text-xs font-medium text-slate-600 mt-1 flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{gig.businessName}</span>
                    {gig.businessVerified && (
                      <CheckCircle2 className="w-3 h-3 text-indigo-600 shrink-0" />
                    )}
                  </p>

                  {/* Description preview */}
                  <p className="text-xs text-slate-500 mt-2.5 line-clamp-3 leading-relaxed">
                    {gig.description}
                  </p>

                  {/* Required skills */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {gig.requiredSkills.map((skill, sIdx) => {
                      const studentHas = currentStudent.skills.some(
                        s => s.toLowerCase() === skill.toLowerCase()
                      );
                      return (
                        <span
                          key={sIdx}
                          className={`text-[10px] font-medium px-2 py-0.5 rounded border ${
                            studentHas
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-slate-50 text-slate-600 border-slate-200'
                          }`}
                        >
                          {skill}
                        </span>
                      );
                    })}
                  </div>

                  {/* Specs footer */}
                  <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Milestone Budget</span>
                      <span className="font-bold text-slate-900 font-mono text-sm">
                        ₹{gig.minBudget.toLocaleString()} - ₹{gig.maxBudget.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Duration & Mode</span>
                      <span className="font-medium text-slate-700 truncate block">
                        {gig.duration} · {gig.workType}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => setSelectedGigId(gig.id)}
                    className="flex-1 py-2 px-3 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    View Details
                  </button>
                  {applied ? (
                    <span className="py-2 px-3 rounded-lg bg-slate-100 text-xs font-semibold text-slate-500 text-center">
                      Applied
                    </span>
                  ) : (
                    <button
                      onClick={() => handleApplyClick(gig)}
                      className="flex-1 py-2 px-3 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors shadow-sm flex items-center justify-center gap-1"
                    >
                      <span>Apply Now</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No matching gigs found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search terms, changing the skill filter, or broadening the budget and location criteria.
          </p>
          <button
            onClick={resetFilters}
            className="px-4 py-2 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      )}
    </div>
  );
};
