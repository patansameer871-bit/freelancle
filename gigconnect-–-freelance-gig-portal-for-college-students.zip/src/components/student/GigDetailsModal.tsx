import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Building2,
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  Users,
  Bookmark,
  Share2,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { Gig } from '../../types';

interface GigDetailsModalProps {
  gig: Gig | null;
  onClose: () => void;
}

export const GigDetailsModal: React.FC = () => {
  const {
    gigs,
    selectedGigId,
    setSelectedGigId,
    toggleSaveGig,
    isGigSaved,
    openApplyModal,
    applications,
    currentStudent,
    calculateMatchScore,
    role,
    openAuthModal
  } = useApp();

  if (!selectedGigId) return null;

  const gig = gigs.find(g => g.id === selectedGigId);
  if (!gig) return null;

  const saved = isGigSaved(gig.id);
  const alreadyApplied = applications.some(
    a => a.gigId === gig.id && a.studentId === currentStudent.id
  );
  const matchScore = calculateMatchScore(gig.requiredSkills, currentStudent.skills);

  const handleApplyClick = () => {
    if (role === 'guest') {
      openAuthModal('login', 'student');
      return;
    }
    openApplyModal(gig);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-full">
              {gig.category}
            </span>
            <span className="text-slate-300">·</span>
            <span className="text-xs text-slate-500">Posted {gig.postedDate}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => toggleSaveGig(gig.id)}
              className={`p-2 rounded-lg border transition-colors ${
                saved
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-600'
                  : 'border-slate-200 text-slate-400 hover:text-slate-600'
              }`}
              title={saved ? 'Bookmarked' : 'Bookmark this gig'}
            >
              <Bookmark className={`w-4 h-4 ${saved ? 'fill-indigo-600' : ''}`} />
            </button>
            <button
              onClick={() => setSelectedGigId(null)}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column (8 cols): Main Spec */}
          <div className="lg:col-span-8 space-y-6">
            <div>
              <h1 className="text-2xl font-extrabold text-slate-900 leading-snug">
                {gig.title}
              </h1>
              <div className="flex items-center gap-2 mt-2 text-xs text-slate-600">
                <span className="font-semibold text-indigo-600">{gig.businessName}</span>
                {gig.businessVerified && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 inline" />
                )}
                <span className="text-slate-300">·</span>
                <span>{gig.businessType}</span>
                <span className="text-slate-300">·</span>
                <span>{gig.businessLocation}</span>
              </div>
            </div>

            {/* Match score callout */}
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                  {matchScore}%
                </div>
                <div>
                  <p className="text-xs font-bold text-emerald-950">
                    High Student Skill Compatibility
                  </p>
                  <p className="text-[11px] text-emerald-700">
                    Your tagged profile skills match the core requirements for this gig.
                  </p>
                </div>
              </div>
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Project Overview
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                {gig.description}
              </p>
            </div>

            {/* Responsibilities */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Key Responsibilities & Deliverables
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-600">
                {gig.responsibilities.map((resp, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Requirements */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Ideal Student Profile & Prerequisites
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-600">
                {gig.requirements.map((req, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Required Skills */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Required Tech & Skills
              </h3>
              <div className="flex flex-wrap gap-2">
                {gig.requiredSkills.map((skill, sIdx) => {
                  const studentHas = currentStudent.skills.some(
                    s => s.toLowerCase() === skill.toLowerCase()
                  );
                  return (
                    <span
                      key={sIdx}
                      className={`text-xs font-medium px-2.5 py-1 rounded-lg border flex items-center gap-1 ${
                        studentHas
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {studentHas && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                      <span>{skill}</span>
                    </span>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column (4 cols): Sticky Action Card */}
          <div className="lg:col-span-4">
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-5 space-y-5">
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold block">
                  Budget (Fixed Milestone)
                </span>
                <p className="text-2xl font-black text-slate-900 font-mono tabular-nums mt-0.5">
                  ₹{gig.minBudget.toLocaleString()} - ₹{gig.maxBudget.toLocaleString()}
                </p>
                <p className="text-[11px] text-slate-500">Direct college bank account transfer</p>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-200 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Duration</span>
                  </span>
                  <span className="font-semibold text-slate-900">{gig.duration}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>Work Mode</span>
                  </span>
                  <span className="font-semibold text-slate-900">{gig.workType}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>Apply Deadline</span>
                  </span>
                  <span className="font-semibold text-slate-900 font-mono">{gig.deadline}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-slate-400" />
                    <span>Applicants</span>
                  </span>
                  <span className="font-semibold text-slate-900 font-mono">
                    {gig.applicantsCount} applied
                  </span>
                </div>
              </div>

              {/* Apply / Action CTA */}
              <div className="pt-3 border-t border-slate-200 space-y-2">
                {alreadyApplied ? (
                  <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 text-center">
                    <p className="text-xs font-semibold text-indigo-700">Application Submitted</p>
                    <p className="text-[10px] text-indigo-600 mt-0.5">
                      Check your "My Applications" tab to track hiring progress.
                    </p>
                  </div>
                ) : (
                  <button
                    onClick={handleApplyClick}
                    className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>Apply for this Gig</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={() => toggleSaveGig(gig.id)}
                  className="w-full py-2 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-slate-700' : ''}`} />
                  <span>{saved ? 'Saved in Bookmarks' : 'Save for Later'}</span>
                </button>
              </div>

              {/* Safety guarantee */}
              <div className="pt-2 flex items-start gap-2 text-[11px] text-slate-500 leading-tight">
                <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>
                  Payments protected by GigConnect Escrow. Client deposits funds prior to milestone kickoff.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
