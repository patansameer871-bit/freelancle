import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  ExternalLink,
  FileText,
  Building2,
  AlertCircle,
  Eye,
  Filter,
  Check,
  MessageSquare
} from 'lucide-react';
import { Application, ApplicationStatus } from '../../types';

export const BusinessApplications: React.FC = () => {
  const {
    applications,
    gigs,
    currentBusiness,
    allStudents,
    updateApplicationStatus,
    setViewStudentModal,
    setMessagesOpen,
    calculateMatchScore
  } = useApp();

  const [selectedGigFilter, setSelectedGigFilter] = useState<string>('All');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('All');

  // Confirmation modal state
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    app: Application | null;
    action: 'Accept' | 'Reject' | 'Shortlist';
    note: string;
  }>({
    isOpen: false,
    app: null,
    action: 'Accept',
    note: ''
  });

  // Business applications
  const businessApps = applications.filter(a => a.businessId === currentBusiness.id);

  // Filtered applications
  const filteredApps = businessApps.filter(app => {
    if (selectedGigFilter !== 'All' && app.gigId !== selectedGigFilter) return false;
    if (selectedStatusFilter !== 'All') {
      if (selectedStatusFilter === 'Shortlisted' && app.status !== 'Under Review') return false;
      if (selectedStatusFilter !== 'Shortlisted' && app.status !== selectedStatusFilter) return false;
    }
    return true;
  });

  // Action triggers
  const handleOpenConfirm = (app: Application, action: 'Accept' | 'Reject' | 'Shortlist') => {
    let defaultNote = '';
    if (action === 'Accept') {
      defaultNote = `Congratulations ${app.studentName}! TechNova Labs has approved your proposal. Let's begin milestone 1!`;
    } else if (action === 'Shortlist') {
      defaultNote = `Your profile has been shortlisted for technical review.`;
    } else {
      defaultNote = `Thank you for applying. We are proceeding with another candidate whose availability aligned better with our launch timeline.`;
    }

    setConfirmDialog({
      isOpen: true,
      app,
      action,
      note: defaultNote
    });
  };

  const handleConfirmAction = () => {
    if (!confirmDialog.app) return;
    const targetStatus: ApplicationStatus =
      confirmDialog.action === 'Accept'
        ? 'Accepted'
        : confirmDialog.action === 'Shortlist'
        ? 'Under Review'
        : 'Rejected';

    updateApplicationStatus(confirmDialog.app.id, targetStatus, confirmDialog.note);
    setConfirmDialog({ isOpen: false, app: null, action: 'Accept', note: '' });
  };

  const handleViewStudentProfile = (studentId: string) => {
    const student = allStudents.find(s => s.id === studentId);
    if (student) {
      setViewStudentModal(student);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Candidate Applications
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Review student applicants, check automated skill match scores, and shortlist or hire candidates.
          </p>
        </div>

        <div className="text-right">
          <span className="text-xs font-semibold text-slate-500">Total Applicants</span>
          <p className="text-2xl font-extrabold text-slate-900 font-mono">
            {businessApps.length}
          </p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-semibold text-slate-700">Filter by Gig:</span>
        </div>
        <select
          value={selectedGigFilter}
          onChange={e => setSelectedGigFilter(e.target.value)}
          className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 max-w-xs truncate"
        >
          <option value="All">All Active Gigs</option>
          {gigs
            .filter(g => g.businessId === currentBusiness.id)
            .map(g => (
              <option key={g.id} value={g.id}>
                {g.title}
              </option>
            ))}
        </select>

        <div className="h-4 w-px bg-slate-200 mx-1 hidden sm:block" />

        <div className="flex items-center gap-1.5 flex-wrap">
          {(['All', 'Pending', 'Shortlisted', 'Accepted', 'Rejected'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setSelectedStatusFilter(tab)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                selectedStatusFilter === tab
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Applications List */}
      {filteredApps.length > 0 ? (
        <div className="space-y-4">
          {filteredApps.map(app => {
            const gig = gigs.find(g => g.id === app.gigId);
            const matchScore = gig
              ? calculateMatchScore(gig.requiredSkills, app.studentSkills)
              : 88;

            return (
              <div
                key={app.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all space-y-4"
              >
                {/* Top Applicant Header */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <img
                      src={app.studentAvatar}
                      alt={app.studentName}
                      className="w-14 h-14 rounded-2xl border border-slate-200 bg-slate-50 object-cover shrink-0 cursor-pointer"
                      onClick={() => handleViewStudentProfile(app.studentId)}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3
                          onClick={() => handleViewStudentProfile(app.studentId)}
                          className="text-base font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors"
                        >
                          {app.studentName}
                        </h3>
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                          <Sparkles className="w-3 h-3 text-emerald-600" />
                          <span>{matchScore}% Match</span>
                        </span>
                      </div>

                      <p className="text-xs text-indigo-600 font-medium mt-0.5">
                        {app.studentCollege}
                      </p>

                      <p className="text-xs text-slate-500 mt-1">
                        Applied for: <strong className="text-slate-800">{app.gigTitle}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="sm:text-right space-y-1">
                    <div className="flex items-center sm:justify-end gap-2">
                      <span className="text-xs text-slate-500">Proposed:</span>
                      <span className="text-lg font-black text-slate-900 font-mono">
                        ₹{app.proposedBudget.toLocaleString()}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block font-mono">
                      Applied {app.appliedDate}
                    </span>
                    <div>
                      <span
                        className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          app.status === 'Accepted'
                            ? 'bg-emerald-100 text-emerald-800'
                            : app.status === 'Under Review'
                            ? 'bg-blue-100 text-blue-800'
                            : app.status === 'Rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        Status: {app.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Candidate Pitch */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Candidate Proposal / Cover Note:
                  </span>
                  <p className="text-slate-700 leading-relaxed italic">
                    "{app.coverNote}"
                  </p>
                </div>

                {/* Skills & Availability Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                      Applicant Skills
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {app.studentSkills.map((s, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px]">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center sm:justify-end gap-3 text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        Availability
                      </span>
                      <span className="font-semibold text-slate-700">{app.studentAvailability}</span>
                    </div>

                    {app.portfolioLinks && app.portfolioLinks.length > 0 && (
                      <a
                        href={app.portfolioLinks[0]}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-indigo-600 hover:bg-slate-50 flex items-center gap-1 font-medium"
                      >
                        <span>Portfolio</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>

                {/* Card Actions (View Profile, Shortlist, Accept, Reject) */}
                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleViewStudentProfile(app.studentId)}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Profile</span>
                    </button>
                    <button
                      onClick={() => setMessagesOpen(true)}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Message</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    {app.status !== 'Under Review' && app.status !== 'Accepted' && (
                      <button
                        onClick={() => handleOpenConfirm(app, 'Shortlist')}
                        className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold transition-colors"
                      >
                        Shortlist Candidate
                      </button>
                    )}

                    {app.status !== 'Accepted' && (
                      <button
                        onClick={() => handleOpenConfirm(app, 'Accept')}
                        className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white shadow-xs transition-colors flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Accept & Hire</span>
                      </button>
                    )}

                    {app.status !== 'Rejected' && (
                      <button
                        onClick={() => handleOpenConfirm(app, 'Reject')}
                        className="px-3 py-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold transition-colors"
                      >
                        Decline
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No applications match your filter</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try switching the gig selector or status tab to view all campus applicants.
          </p>
        </div>
      )}

      {/* Confirmation Dialog */}
      {confirmDialog.isOpen && confirmDialog.app && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  confirmDialog.action === 'Accept'
                    ? 'bg-emerald-100 text-emerald-700'
                    : confirmDialog.action === 'Shortlist'
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-rose-100 text-rose-700'
                }`}
              >
                {confirmDialog.action === 'Accept' ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : confirmDialog.action === 'Shortlist' ? (
                  <Clock className="w-5 h-5" />
                ) : (
                  <XCircle className="w-5 h-5" />
                )}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {confirmDialog.action} Application?
                </h3>
                <p className="text-xs text-slate-500">
                  Candidate: {confirmDialog.app.studentName} ({confirmDialog.app.studentCollege})
                </p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Optional Message / Feedback to Student:
              </label>
              <textarea
                rows={3}
                value={confirmDialog.note}
                onChange={e => setConfirmDialog({ ...confirmDialog, note: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmDialog({ isOpen: false, app: null, action: 'Accept', note: '' })}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmAction}
                className={`px-4 py-2 rounded-lg text-xs font-semibold text-white shadow-xs ${
                  confirmDialog.action === 'Accept'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : confirmDialog.action === 'Shortlist'
                    ? 'bg-blue-600 hover:bg-blue-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                Confirm {confirmDialog.action}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
