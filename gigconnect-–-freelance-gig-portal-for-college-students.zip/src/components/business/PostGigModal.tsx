import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Plus, Trash2, Sparkles, AlertCircle, CheckCircle2, DollarSign, Calendar, Clock, MapPin } from 'lucide-react';

export const PostGigModal: React.FC = () => {
  const { postGigModalOpen, setPostGigModalOpen, postGig, currentBusiness } = useApp();

  const [form, setForm] = useState({
    title: '',
    category: 'Web & App' as const,
    description: '',
    responsibilitiesInput: 'Build responsive components in React\nImplement API integration with backend\nEnsure mobile-friendly viewport layout',
    requirementsInput: 'Strong foundation in React & JavaScript\nGood communication & timeliness\nClean Git commit habits',
    requiredSkillsInput: 'React, Tailwind CSS, REST APIs',
    experienceLevel: 'Beginner Friendly' as const,
    numberOfStudents: 1,
    workType: 'Remote' as const,
    location: currentBusiness.location,
    duration: '2 Weeks',
    availabilityRequirement: '10-15 hrs/week',
    minBudget: 8000,
    maxBudget: 15000,
    deadline: '2026-10-25'
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!postGigModalOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.title.trim()) errs.title = 'Gig title is required';
    if (!form.description.trim() || form.description.length < 20) {
      errs.description = 'Please provide a clear description (at least 20 characters)';
    }
    if (!form.requiredSkillsInput.trim()) errs.skills = 'Specify at least one skill';
    if (form.minBudget <= 0 || form.maxBudget <= 0) {
      errs.budget = 'Please provide valid budget amounts';
    }
    if (form.minBudget > form.maxBudget) {
      errs.budget = 'Minimum budget cannot exceed maximum budget';
    }
    if (!form.deadline) errs.deadline = 'Application deadline is required';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const skills = form.requiredSkillsInput
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);

      const responsibilities = form.responsibilitiesInput
        .split('\n')
        .map(r => r.trim())
        .filter(Boolean);

      const requirements = form.requirementsInput
        .split('\n')
        .map(r => r.trim())
        .filter(Boolean);

      postGig({
        title: form.title,
        category: form.category,
        description: form.description,
        responsibilities: responsibilities.length ? responsibilities : ['Execute agreed sprint deliverables'],
        requirements: requirements.length ? requirements : ['Proactive attitude and proficiency in core skills'],
        requiredSkills: skills.length ? skills : ['General Tech'],
        experienceLevel: form.experienceLevel,
        numberOfStudents: Number(form.numberOfStudents),
        workType: form.workType,
        location: form.location || 'Remote',
        duration: form.duration,
        availabilityRequirement: form.availabilityRequirement,
        minBudget: Number(form.minBudget),
        maxBudget: Number(form.maxBudget),
        deadline: form.deadline
      });

      setIsSubmitting(false);
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            <h3 className="text-base font-bold text-slate-900">Post a New Student Gig</h3>
            <p className="text-xs text-slate-500">
              Publish an opportunity on GigConnect to receive proposals from verified campus talent.
            </p>
          </div>
          <button
            onClick={() => setPostGigModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handlePublish} className="p-6 overflow-y-auto space-y-6">
          {Object.keys(errors).length > 0 && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-2 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Please review the highlighted errors before publishing your gig.</span>
            </div>
          )}

          {/* Section 1: Gig Information */}
          <div className="space-y-3 pb-4 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
              1. Gig Information
            </h4>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Gig Title *
              </label>
              <input
                type="text"
                placeholder="e.g. Build a College Event Website or Design Social Media Branding"
                value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
              />
              {errors.title && <p className="text-[10px] text-rose-500 mt-1">{errors.title}</p>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Category
                </label>
                <select
                  value={form.category}
                  onChange={e => setForm({ ...form, category: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white"
                >
                  <option value="Web & App">Web & App Development</option>
                  <option value="Design & Creative">Design & Creative</option>
                  <option value="Content & Writing">Content & Technical Writing</option>
                  <option value="Data & Analytics">Data & Analytics</option>
                  <option value="Video & Media">Video & Media Editing</option>
                  <option value="Marketing">Social & Growth Marketing</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Experience Level Expected
                </label>
                <select
                  value={form.experienceLevel}
                  onChange={e => setForm({ ...form, experienceLevel: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white"
                >
                  <option value="Beginner Friendly">Beginner Friendly (First-time campus gig)</option>
                  <option value="Intermediate">Intermediate (Has built prior projects)</option>
                  <option value="Advanced">Advanced (Production experience required)</option>
                  <option value="All Levels">All Levels Welcome</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Project Overview / Description *
              </label>
              <textarea
                rows={3}
                placeholder="Describe what your organization is building, what the gig involves, and expected outcomes..."
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
              />
              {errors.description && <p className="text-[10px] text-rose-500 mt-1">{errors.description}</p>}
            </div>
          </div>

          {/* Section 2: Requirements & Skills */}
          <div className="space-y-3 pb-4 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
              2. Skills & Requirements
            </h4>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Required Skills (comma separated) *
              </label>
              <input
                type="text"
                placeholder="e.g. React, Tailwind CSS, TypeScript, Figma"
                value={form.requiredSkillsInput}
                onChange={e => setForm({ ...form, requiredSkillsInput: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500"
              />
              {errors.skills && <p className="text-[10px] text-rose-500 mt-1">{errors.skills}</p>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Deliverables / Responsibilities (1 per line)
                </label>
                <textarea
                  rows={3}
                  value={form.responsibilitiesInput}
                  onChange={e => setForm({ ...form, responsibilitiesInput: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Prerequisites & Qualifications (1 per line)
                </label>
                <textarea
                  rows={3}
                  value={form.requirementsInput}
                  onChange={e => setForm({ ...form, requirementsInput: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                />
              </div>
            </div>

            <div className="w-48">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Number of Students Needed
              </label>
              <input
                type="number"
                min={1}
                max={10}
                value={form.numberOfStudents}
                onChange={e => setForm({ ...form, numberOfStudents: Number(e.target.value) })}
                className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200"
              />
            </div>
          </div>

          {/* Section 3: Work Details & Mode */}
          <div className="space-y-3 pb-4 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
              3. Work Arrangement & Timeline
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Work Mode
                </label>
                <select
                  value={form.workType}
                  onChange={e => setForm({ ...form, workType: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white"
                >
                  <option value="Remote">100% Remote</option>
                  <option value="Hybrid">Hybrid</option>
                  <option value="On-site">On-site</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Estimated Duration
                </label>
                <input
                  type="text"
                  placeholder="e.g. 10 Days or 2 Weeks"
                  value={form.duration}
                  onChange={e => setForm({ ...form, duration: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Expected Availability
                </label>
                <input
                  type="text"
                  placeholder="e.g. 10-15 hrs/week"
                  value={form.availabilityRequirement}
                  onChange={e => setForm({ ...form, availabilityRequirement: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Budget & Deadline */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
              4. Budget & Application Deadline
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Min Budget (₹) *
                </label>
                <input
                  type="number"
                  min={1000}
                  step={500}
                  value={form.minBudget}
                  onChange={e => setForm({ ...form, minBudget: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Max Budget (₹) *
                </label>
                <input
                  type="number"
                  min={1000}
                  step={500}
                  value={form.maxBudget}
                  onChange={e => setForm({ ...form, maxBudget: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Application Deadline *
                </label>
                <input
                  type="date"
                  value={form.deadline}
                  onChange={e => setForm({ ...form, deadline: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200"
                />
              </div>
            </div>
            {errors.budget && <p className="text-[10px] text-rose-500">{errors.budget}</p>}
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setPostGigModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Save Draft & Exit
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Publishing...' : 'Publish Gig Live'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
