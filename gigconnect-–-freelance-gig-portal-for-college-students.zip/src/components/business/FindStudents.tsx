import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Filter,
  Sparkles,
  GraduationCap,
  MapPin,
  Clock,
  Star,
  ExternalLink,
  MessageSquare,
  Eye,
  CheckCircle2,
  Send
} from 'lucide-react';
import { StudentProfile } from '../../types';

export const FindStudents: React.FC = () => {
  const {
    allStudents,
    gigs,
    currentBusiness,
    setViewStudentModal,
    setMessagesOpen,
    calculateMatchScore,
    addToast
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [selectedAvailability, setSelectedAvailability] = useState('All');

  // Business primary active gig required skills for base match calculation
  const businessPrimaryGig = gigs.find(g => g.businessId === currentBusiness.id);
  const benchmarkSkills = businessPrimaryGig ? businessPrimaryGig.requiredSkills : ['React', 'Java', 'UI/UX'];

  // All student skills
  const availableSkills = useMemo(() => {
    const set = new Set<string>();
    allStudents.forEach(s => s.skills.forEach(sk => set.add(sk)));
    return ['All', ...Array.from(set)];
  }, [allStudents]);

  // Ranked students
  const rankedStudents = useMemo(() => {
    return allStudents
      .map(student => {
        // Compute match percentage against benchmark skills
        const match = calculateMatchScore(benchmarkSkills, student.skills);
        return {
          ...student,
          matchScore: match
        };
      })
      .filter(student => {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesName = student.name.toLowerCase().includes(q);
          const matchesCollege = student.college.toLowerCase().includes(q);
          const matchesSkills = student.skills.some(s => s.toLowerCase().includes(q));
          if (!matchesName && !matchesCollege && !matchesSkills) return false;
        }

        if (selectedSkill !== 'All') {
          if (!student.skills.some(s => s.toLowerCase() === selectedSkill.toLowerCase())) return false;
        }

        if (selectedLocation !== 'All') {
          if (!student.location.toLowerCase().includes(selectedLocation.toLowerCase())) return false;
        }

        if (selectedAvailability !== 'All') {
          if (!student.availability.toLowerCase().includes(selectedAvailability.toLowerCase())) return false;
        }

        return true;
      })
      .sort((a, b) => b.matchScore - a.matchScore);
  }, [allStudents, benchmarkSkills, searchQuery, selectedSkill, selectedLocation, selectedAvailability, calculateMatchScore]);

  const handleInvite = (student: StudentProfile) => {
    addToast({
      type: 'success',
      title: 'Invitation Sent',
      message: `Invited ${student.name} to view your open gig "${businessPrimaryGig?.title || 'Active Project'}".`
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-xs font-semibold text-indigo-700 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Campus Talent Matching</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Discover & Hire Top College Students
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Ranked by automated skill compatibility matching your active hiring requirements.
          </p>
        </div>

        {businessPrimaryGig && (
          <div className="bg-indigo-50/70 border border-indigo-200/80 rounded-xl p-3 text-xs">
            <span className="text-[10px] text-slate-500 block uppercase font-bold">Matching Benchmark</span>
            <span className="font-bold text-indigo-900 truncate block max-w-xs">{businessPrimaryGig.title}</span>
            <span className="text-[11px] text-indigo-600 font-mono mt-0.5 block">
              Skills: {businessPrimaryGig.requiredSkills.join(' • ')}
            </span>
          </div>
        )}
      </div>

      {/* Search & Filters */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Search students by name, college (e.g. MIT Pune, IIT Bombay) or skill (React, Java, UI/UX)..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Filter by Skill
            </label>
            <select
              value={selectedSkill}
              onChange={e => setSelectedSkill(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
            >
              {availableSkills.map((s, idx) => (
                <option key={idx} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Location
            </label>
            <select
              value={selectedLocation}
              onChange={e => setSelectedLocation(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
            >
              <option value="All">All Locations</option>
              <option value="Pune">Pune</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Bengaluru">Bengaluru</option>
              <option value="Remote">Remote</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Availability
            </label>
            <select
              value={selectedAvailability}
              onChange={e => setSelectedAvailability(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
            >
              <option value="All">All Availability</option>
              <option value="Immediate">Immediate Hire (15-20 hrs)</option>
              <option value="Part-time">Part-time (10 hrs)</option>
              <option value="Weekends">Weekends only</option>
              <option value="Flexible">Flexible</option>
            </select>
          </div>
        </div>
      </div>

      {/* Ranked Students List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rankedStudents.map(student => (
          <div
            key={student.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all flex flex-col justify-between"
          >
            <div>
              {/* Header with Match % Badge */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <img
                    src={student.avatar}
                    alt={student.name}
                    className="w-12 h-12 rounded-2xl border border-slate-200 bg-slate-50 object-cover"
                  />
                  <div>
                    <h3
                      onClick={() => setViewStudentModal(student)}
                      className="text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors"
                    >
                      {student.name}
                    </h3>
                    <p className="text-[11px] text-slate-500 font-medium truncate max-w-[150px]">
                      {student.college}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <Sparkles className="w-3 h-3 text-emerald-600" />
                    <span>{student.matchScore}% Match</span>
                  </span>
                </div>
              </div>

              {/* Course & Rating */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 pb-2 border-b border-slate-100">
                <span>{student.course}</span>
                <span className="flex items-center gap-0.5 font-bold text-slate-900 font-mono">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                  <span>{student.rating} ★</span>
                </span>
              </div>

              {/* Bio summary */}
              <p className="text-xs text-slate-600 mt-2.5 line-clamp-2 leading-relaxed">
                {student.bio}
              </p>

              {/* Top Skills */}
              <div className="mt-3">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                  Key Skills:
                </span>
                <div className="flex flex-wrap gap-1">
                  {student.skills.slice(0, 4).map((sk, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100"
                    >
                      {sk}
                    </span>
                  ))}
                  {student.skills.length > 4 && (
                    <span className="text-[10px] text-slate-400 self-center">
                      +{student.skills.length - 4} more
                    </span>
                  )}
                </div>
              </div>

              {/* Specs */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span className="truncate max-w-[120px]">{student.availability}</span>
                </span>
                <span className="font-bold text-slate-900 font-mono">{student.hourlyRate}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
              <button
                onClick={() => setViewStudentModal(student)}
                className="flex-1 py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                View Profile
              </button>
              <button
                onClick={() => handleInvite(student)}
                className="flex-1 py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white transition-colors flex items-center justify-center gap-1 shadow-xs"
              >
                <Send className="w-3 h-3" />
                <span>Invite to Gig</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
