import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  GraduationCap,
  MapPin,
  Clock,
  Star,
  ExternalLink,
  FileText,
  Mail,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { StudentProfile } from '../../types';

export const StudentProfileModal: React.FC = () => {
  const { viewStudentModal, setViewStudentModal, setMessagesOpen } = useApp();

  if (!viewStudentModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>Verified Campus Student</span>
            </span>
          </div>
          <button
            onClick={() => setViewStudentModal(null)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Top Info */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-4">
              <img
                src={viewStudentModal.avatar}
                alt={viewStudentModal.name}
                className="w-16 h-16 rounded-2xl border border-slate-200 bg-slate-50 object-cover"
              />
              <div>
                <h3 className="text-lg font-bold text-slate-900">{viewStudentModal.name}</h3>
                <p className="text-xs text-indigo-600 font-medium flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>{viewStudentModal.college}</span>
                </p>
                <p className="text-[11px] text-slate-500">
                  {viewStudentModal.course} · Class of {viewStudentModal.graduationYear}
                </p>
              </div>
            </div>

            <div className="sm:text-right">
              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-xs font-bold text-amber-900 font-mono">
                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>{viewStudentModal.rating} ★ Rating</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 font-mono">
                {viewStudentModal.completedGigsCount} completed gigs
              </p>
            </div>
          </div>

          {/* Availability & Rate */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Availability</span>
              <span className="font-semibold text-slate-800">{viewStudentModal.availability}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Expected Rate</span>
              <span className="font-bold text-slate-900 font-mono">{viewStudentModal.hourlyRate}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 col-span-2 sm:col-span-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Location</span>
              <span className="font-medium text-slate-700">{viewStudentModal.location}</span>
            </div>
          </div>

          {/* Bio */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Candidate Bio
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50/70 p-3.5 rounded-xl border border-slate-100">
              {viewStudentModal.bio}
            </p>
          </div>

          {/* Skills */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Verified Technical & Design Skills
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {viewStudentModal.skills.map((skill, sIdx) => (
                <span
                  key={sIdx}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/80"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Portfolio Projects */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Portfolio & Code Repositories
            </h4>
            <div className="space-y-3">
              {viewStudentModal.portfolio.map(proj => (
                <div
                  key={proj.id}
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-indigo-200 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-slate-900">{proj.title}</h5>
                    <a
                      href={proj.link}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-indigo-600 hover:underline flex items-center gap-1 font-medium"
                    >
                      <span>View Project</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                    {proj.description}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {proj.tags.map((t, idx) => (
                      <span key={idx} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Resume */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Attached Resume
            </h4>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-rose-600" />
                <span className="font-semibold text-slate-800">{viewStudentModal.resumeName}</span>
              </div>
              <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-medium">
                Verified Document
              </span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={() => {
              setViewStudentModal(null);
              setMessagesOpen(true);
            }}
            className="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Send Message</span>
          </button>

          <button
            onClick={() => setViewStudentModal(null)}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white transition-colors"
          >
            Close Profile
          </button>
        </div>
      </div>
    </div>
  );
};
