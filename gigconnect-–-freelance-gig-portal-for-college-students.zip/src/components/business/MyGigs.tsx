import React from 'react';
import { useApp } from '../../context/AppContext';
import { Briefcase, Users, Plus, Calendar, MapPin, Eye, CheckCircle2, Clock } from 'lucide-react';

export const MyGigs: React.FC = () => {
  const { gigs, currentBusiness, setPostGigModalOpen, setSelectedGigId, setActiveTab } = useApp();

  const myGigs = gigs.filter(g => g.businessId === currentBusiness.id);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            My Gigs & Project Listings
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage your published contracts, monitor applicant volume, and track active deliverables.
          </p>
        </div>

        <button
          onClick={() => setPostGigModalOpen(true)}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white shadow-sm transition-all flex items-center gap-1.5"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Post a New Gig</span>
        </button>
      </div>

      {/* Gigs List */}
      {myGigs.length > 0 ? (
        <div className="space-y-4">
          {myGigs.map(gig => (
            <div
              key={gig.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-2 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                    {gig.category}
                  </span>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs text-slate-500">Posted on {gig.postedDate}</span>
                  <span className="text-slate-300">·</span>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Status: {gig.status}</span>
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900">{gig.title}</h3>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {gig.description}
                </p>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>{gig.duration}</span>
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    <span>{gig.workType}</span>
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>Deadline: {gig.deadline}</span>
                  </span>
                </div>
              </div>

              <div className="flex md:flex-col items-center md:items-end justify-between gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                <div className="md:text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Escrow Budget
                  </span>
                  <span className="text-base font-bold text-slate-900 font-mono">
                    ₹{gig.minBudget.toLocaleString()} - ₹{gig.maxBudget.toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedGigId(gig.id);
                      setActiveTab('applications');
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Applicants ({gig.applicantsCount})</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Briefcase className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No gigs posted yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Create your first gig listing to receive applications from talented college students.
          </p>
          <button
            onClick={() => setPostGigModalOpen(true)}
            className="px-4 py-2 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors"
          >
            Post a Gig Now
          </button>
        </div>
      )}
    </div>
  );
};
