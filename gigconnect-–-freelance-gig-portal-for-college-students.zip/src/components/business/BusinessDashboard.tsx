import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Briefcase,
  Users,
  CheckCircle2,
  Clock,
  Plus,
  ArrowRight,
  TrendingUp,
  Sparkles,
  MapPin,
  ExternalLink,
  ChevronRight,
  Eye,
  Star
} from 'lucide-react';
import { Gig } from '../../types';

export const BusinessDashboard: React.FC = () => {
  const {
    currentBusiness,
    gigs,
    applications,
    allStudents,
    setActiveTab,
    setPostGigModalOpen,
    setViewStudentModal,
    setSelectedGigId
  } = useApp();

  // Statistics calculation for business
  const businessGigs = gigs.filter(g => g.businessId === currentBusiness.id);
  const activeGigsCount = businessGigs.filter(g => g.status === 'Active').length;
  const businessApps = applications.filter(a => a.businessId === currentBusiness.id);
  const totalAppsCount = businessApps.length;
  const shortlistedCount = businessApps.filter(a => a.status === 'Under Review').length;
  const completedGigsCount = currentBusiness.hiredStudentsCount;

  // Top 3 recent applications
  const recentApplications = [...businessApps].slice(0, 3);

  // Recommended students
  const topStudents = allStudents.slice(0, 3);

  return (
    <div className="space-y-8 pb-12">
      {/* 1. Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-medium text-indigo-300">
              <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
              <span>Business Client Workspace</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {currentBusiness.companyName}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Hiring Manager: {currentBusiness.name} · {currentBusiness.organizationType} · {currentBusiness.location}
            </p>
            <p className="text-xs text-indigo-200 pt-1">
              You have <strong className="text-white font-mono">{businessApps.length} student proposals</strong> awaiting review across {businessGigs.length} open project listings.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={() => setPostGigModalOpen(true)}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Post a New Gig</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Key Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Card 1: Active Gigs */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Active Gigs</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {activeGigsCount}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Live on campus network</p>
        </div>

        {/* Card 2: Total Applications */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-blue-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Total Applications</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {totalAppsCount}
          </p>
          <p className="text-[11px] text-blue-600 font-medium mt-1">From verified students</p>
        </div>

        {/* Card 3: Shortlisted Students */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-amber-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Shortlisted Students</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {shortlistedCount}
          </p>
          <p className="text-[11px] text-amber-600 font-medium mt-1">Ready for interview/kickoff</p>
        </div>

        {/* Card 4: Completed Gigs */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-200 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Completed Projects</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {completedGigsCount}
          </p>
          <p className="text-[11px] text-emerald-600 font-medium mt-1">100% milestone rating</p>
        </div>
      </div>

      {/* 3. Active Gigs Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Your Active Project Listings</h2>
            <p className="text-xs text-slate-500">Manage deliverables, deadlines, and view applicant pools</p>
          </div>
          <button
            onClick={() => setActiveTab('my-gigs')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>View All ({businessGigs.length})</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {businessGigs.map(gig => (
            <div
              key={gig.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                    {gig.category}
                  </span>
                  <span className="text-xs font-bold text-slate-900 font-mono">
                    ₹{gig.maxBudget.toLocaleString()}
                  </span>
                </div>

                <h3
                  onClick={() => {
                    setSelectedGigId(gig.id);
                    setActiveTab('applications');
                  }}
                  className="text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors leading-snug"
                >
                  {gig.title}
                </h3>

                <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                  {gig.description}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    <strong>{gig.applicantsCount}</strong> applicants
                  </span>
                  <span>Deadline: {gig.deadline}</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => {
                    setSelectedGigId(gig.id);
                    setActiveTab('applications');
                  }}
                  className="flex-1 py-1.5 px-3 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-xs font-semibold text-indigo-700 transition-colors"
                >
                  Review Applicants
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Recent Applications Feed */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Recent Student Applications</h2>
            <p className="text-xs text-slate-500">Students who submitted proposals for your gigs</p>
          </div>
          <button
            onClick={() => setActiveTab('applications')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            Manage All Applications
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-sm">
          {recentApplications.map(app => (
            <div
              key={app.id}
              className="p-4 sm:p-5 hover:bg-slate-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3.5">
                <img
                  src={app.studentAvatar}
                  alt={app.studentName}
                  className="w-11 h-11 rounded-2xl border border-slate-200 bg-slate-50 object-cover shrink-0"
                />
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900">{app.studentName}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-indigo-600 font-medium">{app.studentCollege}</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Applied for: <strong className="text-slate-800">{app.gigTitle}</strong>
                  </p>
                  <p className="text-[11px] text-slate-500 italic truncate max-w-md">
                    "{app.coverNote}"
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 sm:self-center">
                <div className="text-right sm:pr-3">
                  <span className="text-sm font-bold text-slate-900 font-mono">
                    ₹{app.proposedBudget.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-normal">Proposed Fee</span>
                </div>
                <button
                  onClick={() => setActiveTab('applications')}
                  className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors shadow-xs"
                >
                  Review
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Recommended Students */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Recommended Campus Talent</h2>
            <p className="text-xs text-slate-500">High-rated students matching your active skill requirements</p>
          </div>
          <button
            onClick={() => setActiveTab('find-students')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            Find More Students
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {topStudents.map(student => (
            <div
              key={student.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <img
                    src={student.avatar}
                    alt={student.name}
                    className="w-10 h-10 rounded-2xl border border-slate-200 bg-slate-50 object-cover"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{student.name}</h3>
                    <p className="text-[11px] text-slate-500">{student.college}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 py-1.5 border-y border-slate-100 mb-2">
                  <span className="flex items-center gap-1 font-mono text-slate-900 font-bold">
                    <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                    <span>{student.rating} ★</span>
                  </span>
                  <span>{student.completedGigsCount} completed</span>
                  <span className="font-mono font-bold text-indigo-700">{student.hourlyRate}</span>
                </div>

                <div className="flex flex-wrap gap-1 mt-2">
                  {student.skills.slice(0, 3).map((sk, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600"
                    >
                      {sk}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => setViewStudentModal(student)}
                  className="w-full py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  View Profile
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
