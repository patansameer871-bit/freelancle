import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, User, Building2, Sparkles, Check, ArrowRight } from 'lucide-react';
import { INITIAL_STUDENT, INITIAL_BUSINESS } from '../../data/mockData';

import { BusinessProfile } from '../../types';

export const AuthModal: React.FC = () => {
  const { authModal, closeAuthModal, loginAsStudent, loginAsBusiness } = useApp();

  const [role, setRole] = useState<'student' | 'business'>(authModal.defaultRole || 'student');
  const [isRegister, setIsRegister] = useState(authModal.mode === 'register');

  // Student form state
  const [studentForm, setStudentForm] = useState({
    name: '',
    email: '',
    password: '',
    college: '',
    course: 'B.Tech Computer Science',
    skills: 'React, Java, UI/UX, Python'
  });

  // Business form state
  const [businessForm, setBusinessForm] = useState({
    name: '',
    companyName: '',
    email: '',
    password: '',
    organizationType: 'Startup' as BusinessProfile['organizationType']
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!authModal.isOpen) return null;

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (role === 'student') {
      if (!studentForm.email) newErrors.email = 'Email is required';
      if (!studentForm.password) newErrors.password = 'Password is required';
      if (isRegister) {
        if (!studentForm.name) newErrors.name = 'Full name is required';
        if (!studentForm.college) newErrors.college = 'College/University name is required';
      }
    } else {
      if (!businessForm.email) newErrors.email = 'Business email is required';
      if (!businessForm.password) newErrors.password = 'Password is required';
      if (isRegister) {
        if (!businessForm.companyName) newErrors.companyName = 'Company name is required';
        if (!businessForm.name) newErrors.name = 'Contact person name is required';
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (role === 'student') {
      const skillsArray = studentForm.skills
        ? studentForm.skills.split(',').map(s => s.trim()).filter(Boolean)
        : ['React', 'TypeScript', 'Java'];

      loginAsStudent({
        name: studentForm.name || INITIAL_STUDENT.name,
        email: studentForm.email,
        college: studentForm.college || INITIAL_STUDENT.college,
        course: studentForm.course,
        skills: skillsArray.length ? skillsArray : INITIAL_STUDENT.skills
      });
    } else {
      loginAsBusiness({
        name: businessForm.name || INITIAL_BUSINESS.name,
        companyName: businessForm.companyName || INITIAL_BUSINESS.companyName,
        email: businessForm.email,
        organizationType: businessForm.organizationType
      });
    }
  };

  const fillDemoData = (targetRole: 'student' | 'business') => {
    if (targetRole === 'student') {
      setRole('student');
      setStudentForm({
        name: INITIAL_STUDENT.name,
        email: INITIAL_STUDENT.email,
        password: 'password123',
        college: INITIAL_STUDENT.college,
        course: INITIAL_STUDENT.course,
        skills: INITIAL_STUDENT.skills.join(', ')
      });
      setErrors({});
    } else {
      setRole('business');
      setBusinessForm({
        name: INITIAL_BUSINESS.name,
        companyName: INITIAL_BUSINESS.companyName,
        email: INITIAL_BUSINESS.email,
        password: 'password123',
        organizationType: INITIAL_BUSINESS.organizationType
      });
      setErrors({});
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-md bg-[#0e131f] rounded-2xl shadow-2xl border border-amber-500/30 overflow-hidden my-8 text-slate-200">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 border-b border-amber-500/20 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">
              {isRegister ? 'Join GigConnect' : 'Welcome Back'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isRegister ? 'Create an account to start earning or hiring' : 'Log into your account to continue'}
            </p>
          </div>
          <button
            onClick={closeAuthModal}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Demo Fast-Fill Pill (Judge helper) */}
        <div className="bg-[#141b2a] border-b border-amber-500/20 px-6 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-amber-300 font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 fill-amber-400" />
            <span>Hackathon Quick Fill:</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fillDemoData('student')}
              className="text-[11px] font-bold text-amber-400 hover:underline"
            >
              Fill Student
            </button>
            <span className="text-amber-500/40">·</span>
            <button
              type="button"
              onClick={() => fillDemoData('business')}
              className="text-[11px] font-bold text-amber-400 hover:underline"
            >
              Fill Business
            </button>
          </div>
        </div>

        {/* Role Toggle Selector */}
        <div className="px-6 pt-4">
          <label className="text-[11px] font-bold uppercase tracking-wider text-amber-400/80 block mb-2">
            Select Your Role
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setRole('student')}
              className={`p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                role === 'student'
                  ? 'border-amber-400 bg-amber-500/15 text-white shadow-sm ring-1 ring-amber-400/50'
                  : 'border-slate-800 bg-[#121722] hover:border-slate-700 text-slate-400'
              }`}
            >
              <User className={`w-4 h-4 mt-0.5 ${role === 'student' ? 'text-amber-400' : 'text-slate-500'}`} />
              <div>
                <p className="text-xs font-bold leading-tight">Student</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Find & complete gigs</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setRole('business')}
              className={`p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                role === 'business'
                  ? 'border-amber-400 bg-amber-500/15 text-white shadow-sm ring-1 ring-amber-400/50'
                  : 'border-slate-800 bg-[#121722] hover:border-slate-700 text-slate-400'
              }`}
            >
              <Building2 className={`w-4 h-4 mt-0.5 ${role === 'business' ? 'text-amber-400' : 'text-slate-500'}`} />
              <div>
                <p className="text-xs font-bold leading-tight">Business / Client</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Post gigs & hire talent</p>
              </div>
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-6 py-4 space-y-3.5">
          {role === 'student' ? (
            <>
              {isRegister && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Aarav Sharma"
                      value={studentForm.name}
                      onChange={e => setStudentForm({ ...studentForm, name: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.name && <p className="text-[10px] text-rose-400 mt-1">{errors.name}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      College / University *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. MIT World Peace University, Pune"
                      value={studentForm.college}
                      onChange={e => setStudentForm({ ...studentForm, college: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.college && <p className="text-[10px] text-rose-400 mt-1">{errors.college}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Key Skills (comma separated)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. React, Java, UI/UX, Python"
                      value={studentForm.skills}
                      onChange={e => setStudentForm({ ...studentForm, skills: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  placeholder="student@college.edu.in"
                  value={studentForm.email}
                  onChange={e => setStudentForm({ ...studentForm, email: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {errors.email && <p className="text-[10px] text-rose-400 mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={studentForm.password}
                  onChange={e => setStudentForm({ ...studentForm, password: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {errors.password && <p className="text-[10px] text-rose-400 mt-1">{errors.password}</p>}
              </div>
            </>
          ) : (
            <>
              {isRegister && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Business / Organization Name *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. TechNova Labs"
                      value={businessForm.companyName}
                      onChange={e => setBusinessForm({ ...businessForm, companyName: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.companyName && <p className="text-[10px] text-rose-400 mt-1">{errors.companyName}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Contact Person Name *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Priya Nambiar"
                      value={businessForm.name}
                      onChange={e => setBusinessForm({ ...businessForm, name: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {errors.name && <p className="text-[10px] text-rose-400 mt-1">{errors.name}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Organization Type
                    </label>
                    <select
                      value={businessForm.organizationType}
                      onChange={e => setBusinessForm({ ...businessForm, organizationType: e.target.value as any })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Startup">Early-Stage Startup</option>
                      <option value="Local Business">Local Business / Café / Store</option>
                      <option value="Tech Agency">Tech & Design Agency</option>
                      <option value="College Club / Dept">College Fest / Student Club</option>
                      <option value="E-commerce Brand">E-commerce Brand</option>
                    </select>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Business Email *
                </label>
                <input
                  type="email"
                  placeholder="contact@company.com"
                  value={businessForm.email}
                  onChange={e => setBusinessForm({ ...businessForm, email: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {errors.email && <p className="text-[10px] text-rose-400 mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={businessForm.password}
                  onChange={e => setBusinessForm({ ...businessForm, password: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-amber-500/25 bg-[#121722] text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {errors.password && <p className="text-[10px] text-rose-400 mt-1">{errors.password}</p>}
              </div>
            </>
          )}

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-2.5 px-4 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 rounded-xl hover:from-amber-300 hover:to-yellow-300 shadow-lg shadow-amber-500/25 transition-all flex items-center justify-center gap-1.5 mt-2"
          >
            <span>{isRegister ? `Register as ${role === 'student' ? 'Student' : 'Business'}` : `Sign In as ${role === 'student' ? 'Student' : 'Business'}`}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Toggle Login / Register */}
        <div className="px-6 pb-6 pt-2 border-t border-amber-500/20 text-center">
          <p className="text-xs text-slate-400">
            {isRegister ? 'Already have an account?' : "Don't have an account yet?"}{' '}
            <button
              type="button"
              onClick={() => {
                setIsRegister(!isRegister);
                setErrors({});
              }}
              className="text-xs font-bold text-amber-400 hover:underline"
            >
              {isRegister ? 'Sign In' : 'Create Free Account'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
