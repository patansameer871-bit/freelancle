/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DemoSwitcherBar } from './components/common/DemoSwitcherBar';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { ToastContainer } from './components/common/ToastContainer';
import { AppLayout } from './components/layout/AppLayout';

// Landing & Public
import { LandingPage } from './components/landing/LandingPage';

// Student Views
import { StudentDashboard } from './components/student/StudentDashboard';
import { FindGigs } from './components/student/FindGigs';
import { MyApplications } from './components/student/MyApplications';
import { SavedGigs } from './components/student/SavedGigs';
import { StudentProfile } from './components/student/StudentProfile';

// Business Views
import { BusinessDashboard } from './components/business/BusinessDashboard';
import { MyGigs } from './components/business/MyGigs';
import { BusinessApplications } from './components/business/BusinessApplications';
import { FindStudents } from './components/business/FindStudents';

// Global Modals
import { AuthModal } from './components/auth/AuthModal';
import { GigDetailsModal } from './components/student/GigDetailsModal';
import { ApplyGigModal } from './components/student/ApplyGigModal';
import { PostGigModal } from './components/business/PostGigModal';
import { StudentProfileModal } from './components/business/StudentProfileModal';
import { NotificationDrawer } from './components/notifications/NotificationDrawer';
import { MessagesModal } from './components/chat/MessagesModal';

const AppContent: React.FC = () => {
  const { role, activeTab } = useApp();

  const renderContent = () => {
    // 1. Guest Visitor View
    if (role === 'guest') {
      if (activeTab === 'find-gigs') {
        return (
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <FindGigs />
          </main>
        );
      }
      return <LandingPage />;
    }

    // 2. Student Role
    if (role === 'student') {
      return (
        <AppLayout>
          {activeTab === 'dashboard' && <StudentDashboard />}
          {activeTab === 'find-gigs' && <FindGigs />}
          {activeTab === 'my-applications' && <MyApplications />}
          {activeTab === 'saved-gigs' && <SavedGigs />}
          {activeTab === 'profile' && <StudentProfile />}
          {activeTab !== 'dashboard' &&
            activeTab !== 'find-gigs' &&
            activeTab !== 'my-applications' &&
            activeTab !== 'saved-gigs' &&
            activeTab !== 'profile' && <StudentDashboard />}
        </AppLayout>
      );
    }

    // 3. Business Role
    if (role === 'business') {
      return (
        <AppLayout>
          {activeTab === 'dashboard' && <BusinessDashboard />}
          {activeTab === 'my-gigs' && <MyGigs />}
          {activeTab === 'applications' && <BusinessApplications />}
          {activeTab === 'find-students' && <FindStudents />}
          {activeTab !== 'dashboard' &&
            activeTab !== 'my-gigs' &&
            activeTab !== 'applications' &&
            activeTab !== 'find-students' && <BusinessDashboard />}
        </AppLayout>
      );
    }

    return <LandingPage />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#090a0f] text-slate-100 selection:bg-amber-400 selection:text-slate-950">
      {/* Top Hackathon Demo Bar for instant judging */}
      <DemoSwitcherBar />

      {/* Main Top Navigation */}
      <Navbar />

      {/* Active View */}
      <div className="flex-1">{renderContent()}</div>

      {/* Footer */}
      <Footer />

      {/* Modals & Overlays */}
      <AuthModal />
      <GigDetailsModal />
      <ApplyGigModal />
      <PostGigModal />
      <StudentProfileModal />
      <NotificationDrawer />
      <MessagesModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
