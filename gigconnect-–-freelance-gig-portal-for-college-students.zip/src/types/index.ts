export type UserRole = 'student' | 'business' | 'guest';

export interface SkillItem {
  name: string;
  category: 'Tech' | 'Design' | 'Marketing' | 'Content' | 'Data' | 'Operations';
  level: 'Beginner' | 'Intermediate' | 'Expert';
}

export interface PortfolioProject {
  id: string;
  title: string;
  description: string;
  link: string;
  github?: string;
  tags: string[];
}

export interface StudentProfile {
  id: string;
  name: string;
  email: string;
  college: string;
  course: string;
  graduationYear: number;
  location: string;
  bio: string;
  skills: string[];
  availability: 'Immediate (15-20 hrs/wk)' | 'Part-time (10 hrs/wk)' | 'Weekends only' | 'Flexible';
  hourlyRate: string;
  avatar: string;
  portfolio: PortfolioProject[];
  resumeName: string;
  resumeUrl: string;
  completedGigsCount: number;
  rating: number;
  totalEarnings: number;
  phone: string;
  github: string;
  linkedin: string;
}

export interface BusinessProfile {
  id: string;
  name: string;
  companyName: string;
  email: string;
  organizationType: 'Startup' | 'Local Business' | 'Tech Agency' | 'College Club / Dept' | 'E-commerce Brand';
  location: string;
  verified: boolean;
  avatar: string;
  website: string;
  description: string;
  industry: string;
  activeGigsCount: number;
  hiredStudentsCount: number;
}

export interface Gig {
  id: string;
  title: string;
  businessId: string;
  businessName: string;
  businessType: string;
  businessLocation: string;
  businessVerified: boolean;
  category: 'Web & App' | 'Design & Creative' | 'Content & Writing' | 'Data & Analytics' | 'Video & Media' | 'Marketing';
  description: string;
  responsibilities: string[];
  requirements: string[];
  requiredSkills: string[];
  experienceLevel: 'All Levels' | 'Beginner Friendly' | 'Intermediate' | 'Advanced';
  numberOfStudents: number;
  workType: 'Remote' | 'Hybrid' | 'On-site';
  location: string;
  duration: string;
  availabilityRequirement: string;
  minBudget: number;
  maxBudget: number;
  deadline: string;
  postedDate: string;
  status: 'Active' | 'Under Review' | 'Completed' | 'Closed';
  applicantsCount: number;
  featured?: boolean;
}

export type ApplicationStatus = 'Pending' | 'Under Review' | 'Accepted' | 'In Progress' | 'Completed' | 'Rejected';

export interface ApplicationTimelineItem {
  status: ApplicationStatus;
  date: string;
  note?: string;
}

export interface Application {
  id: string;
  gigId: string;
  gigTitle: string;
  businessId: string;
  businessName: string;
  studentId: string;
  studentName: string;
  studentCollege: string;
  studentAvatar: string;
  studentSkills: string[];
  studentAvailability: string;
  appliedDate: string;
  proposedBudget: number;
  coverNote: string;
  portfolioLinks: string[];
  status: ApplicationStatus;
  timeline: ApplicationTimelineItem[];
  clientFeedback?: string;
  rating?: number;
}

export interface NotificationItem {
  id: string;
  userId: string;
  role: 'student' | 'business' | 'all';
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'gig' | 'application' | 'message' | 'system';
  linkTab?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'student' | 'business';
  recipientId: string;
  text: string;
  timestamp: string;
  gigTitle?: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  message: string;
}
