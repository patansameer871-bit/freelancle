import { Gig, StudentProfile, BusinessProfile, Application, NotificationItem, ChatMessage } from '../types';

export const INITIAL_STUDENT: StudentProfile = {
  id: 'student-1',
  name: 'Aarav Sharma',
  email: 'aarav.sharma@mitwpu.edu.in',
  college: 'MIT World Peace University, Pune',
  course: 'B.Tech in Computer Science & Engineering',
  graduationYear: 2026,
  location: 'Pune, Maharashtra',
  bio: 'Third-year CS student passionate about full-stack web development and clean UI design. Built 4 production web apps and hackathon winners. Looking for challenging freelance gigs to deliver real impact.',
  skills: ['React', 'TypeScript', 'Java', 'Spring Boot', 'UI/UX', 'Tailwind CSS', 'Node.js', 'PostgreSQL'],
  availability: 'Immediate (15-20 hrs/wk)',
  hourlyRate: '₹600/hr',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aarav&backgroundColor=c0aede,b6e3f4',
  portfolio: [
    {
      id: 'proj-1',
      title: 'AuraCampus - Student Marketplace',
      description: 'Built a peer-to-peer campus marketplace where students exchange textbooks and lab equipment.',
      link: 'https://auracampus.demo.app',
      github: 'https://github.com/aaravsharma/auracampus',
      tags: ['React', 'Node.js', 'Tailwind', 'MongoDB']
    },
    {
      id: 'proj-2',
      title: 'DevSprint Hackathon Portal',
      description: 'Official registration & judging portal used by 600+ participants during the annual college tech fest.',
      link: 'https://devsprint26.vercel.app',
      tags: ['TypeScript', 'Next.js', 'PostgreSQL']
    },
    {
      id: 'proj-3',
      title: 'FinTrack Personal Finance Tool',
      description: 'Interactive analytics dashboard tracking monthly college expenses and pocket money budgets.',
      link: 'https://fintrack-demo.app',
      tags: ['React', 'Recharts', 'Tailwind']
    }
  ],
  resumeName: 'Aarav_Sharma_Resume_2026.pdf',
  resumeUrl: '#',
  completedGigsCount: 4,
  rating: 4.9,
  totalEarnings: 38500,
  phone: '+91 98230 45678',
  github: 'https://github.com/aaravsharma',
  linkedin: 'https://linkedin.com/in/aaravsharma-dev'
};

export const INITIAL_BUSINESS: BusinessProfile = {
  id: 'biz-1',
  name: 'Priya Nambiar',
  companyName: 'TechNova Labs & Studios',
  email: 'priya@technovalabs.io',
  organizationType: 'Startup',
  location: 'Bengaluru / Hybrid',
  verified: true,
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya&backgroundColor=ffd5dc,d1d4f9',
  website: 'https://technovalabs.io',
  description: 'Fast-paced venture-backed consumer tech studio creating next-gen productivity and collaboration tools. We love hiring high-energy college talent for fast turnaround sprints.',
  industry: 'Software & Digital Media',
  activeGigsCount: 3,
  hiredStudentsCount: 14
};

export const OTHER_STUDENTS: StudentProfile[] = [
  {
    id: 'student-2',
    name: 'Ananya Deshmukh',
    email: 'ananya.d@coep.ac.in',
    college: 'COEP Technological University, Pune',
    course: 'B.Des in Visual Communication',
    graduationYear: 2025,
    location: 'Pune, Maharashtra',
    bio: 'Visual designer and illustrator. Specialized in Figma brand identity systems, social media carousels, and vector asset generation for fast-growing startups.',
    skills: ['UI/UX', 'Figma', 'Graphic Design', 'Instagram Branding', 'Illustrator', 'Motion Graphics'],
    availability: 'Part-time (10 hrs/wk)',
    hourlyRate: '₹500/hr',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ananya&backgroundColor=ffdfbf,ffd5dc',
    portfolio: [
      {
        id: 'proj-201',
        title: 'Kavya Organics Brand Identity',
        description: 'Complete brand guide, typography selection, packaging labels, and 30 social media launch assets.',
        link: 'https://behance.net/ananyadeshmukh',
        tags: ['Figma', 'Illustrator', 'Branding']
      }
    ],
    resumeName: 'Ananya_Deshmukh_Design_CV.pdf',
    resumeUrl: '#',
    completedGigsCount: 7,
    rating: 5.0,
    totalEarnings: 52000,
    phone: '+91 98110 32145',
    github: '',
    linkedin: 'https://linkedin.com/in/ananya-deshmukh-design'
  },
  {
    id: 'student-3',
    name: 'Rohan Verma',
    email: 'rohan.v@iitb.ac.in',
    college: 'IIT Bombay',
    course: 'B.Tech in Electrical Engineering & CS Minor',
    graduationYear: 2026,
    location: 'Mumbai, Maharashtra',
    bio: 'Backend systems enthusiast with strong foundations in Java, Spring Boot, REST APIs, and microservices architecture. Competitive programmer (Codeforces Candidate Master).',
    skills: ['Java', 'Spring Boot', 'Python', 'PostgreSQL', 'Docker', 'REST APIs', 'Data Structures'],
    availability: 'Immediate (15-20 hrs/wk)',
    hourlyRate: '₹750/hr',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rohan&backgroundColor=b6e3f4,c0aede',
    portfolio: [
      {
        id: 'proj-301',
        title: 'High-Concurrency Order Matching Engine',
        description: 'Engineered a low-latency matching engine handling 10k mock orders/sec with thread-safe queues.',
        link: 'https://github.com/rohanverma/order-engine',
        tags: ['Java', 'Spring Boot', 'Redis']
      }
    ],
    resumeName: 'Rohan_Verma_IITB_Resume.pdf',
    resumeUrl: '#',
    completedGigsCount: 3,
    rating: 4.8,
    totalEarnings: 31000,
    phone: '+91 97321 88990',
    github: 'https://github.com/rohanverma',
    linkedin: 'https://linkedin.com/in/rohanverma-iitb'
  },
  {
    id: 'student-4',
    name: 'Tanvi Kulkarni',
    email: 'tanvi.k@vit.edu',
    college: 'VIT Pune',
    course: 'B.Tech in Information Technology',
    graduationYear: 2026,
    location: 'Pune, Maharashtra',
    bio: 'Python automation and data engineering nerd. Love turning messy spreadsheets into clean automated pipelines, dashboards, and automated email dispatchers.',
    skills: ['Python', 'Data Analytics', 'Excel Automation', 'Pandas', 'Web Scraping', 'SQL', 'Tableau'],
    availability: 'Flexible',
    hourlyRate: '₹450/hr',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Tanvi&backgroundColor=ffd5dc,ffdfbf',
    portfolio: [
      {
        id: 'proj-401',
        title: 'GST Invoice Parsing & Reconciliation Bot',
        description: 'Automated extraction of supplier GST details from 500+ PDFs into categorized Excel ledger.',
        link: 'https://github.com/tanvikulkarni/gst-bot',
        tags: ['Python', 'OpenPyXL', 'OCR']
      }
    ],
    resumeName: 'Tanvi_Kulkarni_DataCV.pdf',
    resumeUrl: '#',
    completedGigsCount: 5,
    rating: 4.9,
    totalEarnings: 28000,
    phone: '+91 99221 44556',
    github: 'https://github.com/tanvikulkarni',
    linkedin: 'https://linkedin.com/in/tanvikulkarni'
  },
  {
    id: 'student-5',
    name: 'Vikramaditya Roy',
    email: 'vikram.roy@manipal.edu',
    college: 'Manipal Institute of Technology',
    course: 'B.Tech in Computer & Communication',
    graduationYear: 2025,
    location: 'Bengaluru / Remote',
    bio: 'Short-form video editor and digital storyteller. Created reels and product videos clocking 2M+ views on YouTube Shorts and Instagram. Proficient in Premiere Pro & DaVinci Resolve.',
    skills: ['Video Editing', 'Premiere Pro', 'After Effects', 'Content Writing', 'Color Grading', 'Sound Design'],
    availability: 'Weekends only',
    hourlyRate: '₹550/hr',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Vikram&backgroundColor=d1d4f9,b6e3f4',
    portfolio: [
      {
        id: 'proj-501',
        title: 'FinTech Startup 45-Sec Promo Reel',
        description: 'High-retention product launch reel featuring sound sync, 3D text tracking, and typography animations.',
        link: 'https://youtube.com/shorts/demo',
        tags: ['Premiere Pro', 'After Effects']
      }
    ],
    resumeName: 'Vikram_Roy_Showreel_CV.pdf',
    resumeUrl: '#',
    completedGigsCount: 9,
    rating: 5.0,
    totalEarnings: 64000,
    phone: '+91 91672 33445',
    github: '',
    linkedin: 'https://linkedin.com/in/vikram-roy-media'
  }
];

export const INITIAL_GIGS: Gig[] = [
  {
    id: 'gig-1',
    title: 'Build a College Event Website',
    businessId: 'biz-1',
    businessName: 'TechNova Labs & Studios',
    businessType: 'Startup',
    businessLocation: 'Bengaluru, Karnataka (Remote)',
    businessVerified: true,
    category: 'Web & App',
    description: 'We are organizing "Genesis Hack 2026", an inter-college robotics and hackathon festival. We need a creative, responsive event landing page with schedule explorer, speaker roster, sponsor showcases, and Google Forms or API registration link. Must look ultra-modern and run flawlessly on mobile devices.',
    responsibilities: [
      'Design and code a responsive single-page festival website using modern frontend tools (React / Tailwind).',
      'Implement an interactive timeline/schedule component for 3 days of hackathon events.',
      'Embed registration CTA modal and FAQ accordion section.',
      'Deploy to Vercel/Netlify with custom domain connection.'
    ],
    requirements: [
      'Good grasp of React, Tailwind CSS, or modern HTML/CSS.',
      'Eye for visual aesthetics, dark/light themes, and clean spacing.',
      'Ability to complete deliverables within 10 days.'
    ],
    requiredSkills: ['React', 'Tailwind CSS', 'UI/UX', 'Responsive Design'],
    experienceLevel: 'Beginner Friendly',
    numberOfStudents: 2,
    workType: 'Remote',
    location: 'Remote',
    duration: '10 Days',
    availabilityRequirement: '10-15 hrs/week',
    minBudget: 8000,
    maxBudget: 14000,
    deadline: '2026-10-18',
    postedDate: '2026-10-02',
    status: 'Active',
    applicantsCount: 6,
    featured: true
  },
  {
    id: 'gig-2',
    title: 'Design Instagram Posts for Local Business',
    businessId: 'biz-2',
    businessName: 'GreenLeaf Artisan Roasters',
    businessType: 'Local Business',
    businessLocation: 'Koregaon Park, Pune',
    businessVerified: true,
    category: 'Design & Creative',
    description: 'A popular specialty coffee café and roastery in Pune looking to level up their Instagram presence. We need 12 beautifully branded static posts and 4 carousel slides showcasing our single-origin pour-overs, cold brews, and cozy weekend atmosphere.',
    responsibilities: [
      'Create 12 aesthetic feed posts and 4 informative carousel sets in Figma or Canva.',
      'Follow our earthy, minimalist warm aesthetic guidelines.',
      'Provide ready-to-publish high-res PNG files along with editable source links.'
    ],
    requirements: [
      'Proficiency in Figma, Canva, or Adobe Photoshop/Illustrator.',
      'Strong typography, color harmony, and social media layout sense.',
      'Previous portfolio links of social media work.'
    ],
    requiredSkills: ['Graphic Design', 'UI/UX', 'Instagram Branding', 'Figma'],
    experienceLevel: 'All Levels',
    numberOfStudents: 1,
    workType: 'Remote',
    location: 'Pune / Remote',
    duration: '2 Weeks',
    availabilityRequirement: '8 hrs/week',
    minBudget: 5000,
    maxBudget: 8500,
    deadline: '2026-10-22',
    postedDate: '2026-10-01',
    status: 'Active',
    applicantsCount: 9,
    featured: true
  },
  {
    id: 'gig-3',
    title: 'Develop a Java Backend API',
    businessId: 'biz-1',
    businessName: 'TechNova Labs & Studios',
    businessType: 'Startup',
    businessLocation: 'Bengaluru / Remote',
    businessVerified: true,
    category: 'Web & App',
    description: 'Need a talented student backend engineer to build a Spring Boot REST API microservice for our attendance tracking and token validation module. Clean layered architecture (Controller, Service, Repository) with unit tests and OpenAPI/Swagger documentation.',
    responsibilities: [
      'Write production-grade Java 21 + Spring Boot 3 REST endpoints.',
      'Implement JWT-based authentication filter and role checks.',
      'Set up PostgreSQL database migrations with Liquibase/Flyway.',
      'Write clean Postman collections and Swagger API documentation.'
    ],
    requirements: [
      'Solid command of Core Java, OOP, Collections, and Spring Boot.',
      'Familiarity with SQL / PostgreSQL queries and JPA/Hibernate.',
      'Code quality discipline and Git version control habits.'
    ],
    requiredSkills: ['Java', 'Spring Boot', 'PostgreSQL', 'REST APIs'],
    experienceLevel: 'Intermediate',
    numberOfStudents: 1,
    workType: 'Remote',
    location: 'Remote',
    duration: '3 Weeks',
    availabilityRequirement: '15 hrs/week',
    minBudget: 15000,
    maxBudget: 22000,
    deadline: '2026-10-25',
    postedDate: '2026-10-03',
    status: 'Active',
    applicantsCount: 4,
    featured: true
  },
  {
    id: 'gig-4',
    title: 'Create a Product Promo Video',
    businessId: 'biz-3',
    businessName: 'OrbitDesk Ergonomics',
    businessType: 'E-commerce Brand',
    businessLocation: 'Mumbai / Remote',
    businessVerified: true,
    category: 'Video & Media',
    description: 'We are launching a portable laptop stand for students and nomads. We have raw 4K unboxing clips and b-roll footage. We need a snappy 30-45 second video with kinetic subtitles, trendy audio beats, and feature callouts for Meta & Instagram Ads.',
    responsibilities: [
      'Cut and edit raw clips into a high-converting 9:16 vertical promotional video.',
      'Add synchronized motion typography, subtle sound effects, and smooth transitions.',
      'Deliver final vertical (1080x1920) and horizontal (1920x1080) cuts.'
    ],
    requirements: [
      'Hands-on experience in Premiere Pro, DaVinci Resolve, or CapCut Pro.',
      'Good sense of pacing, rhythm, and hook psychology.',
      'Share links to 2 recent video edits.'
    ],
    requiredSkills: ['Video Editing', 'After Effects', 'Premiere Pro', 'Content Writing'],
    experienceLevel: 'All Levels',
    numberOfStudents: 1,
    workType: 'Remote',
    location: 'Remote',
    duration: '1 Week',
    availabilityRequirement: '10 hrs total',
    minBudget: 6000,
    maxBudget: 10000,
    deadline: '2026-10-15',
    postedDate: '2026-10-04',
    status: 'Active',
    applicantsCount: 5,
    featured: false
  },
  {
    id: 'gig-5',
    title: 'Create a Business Logo & Brand Kit',
    businessId: 'biz-4',
    businessName: 'Saffron Roots Eco-Foods',
    businessType: 'Startup',
    businessLocation: 'Ahmedabad / Remote',
    businessVerified: false,
    category: 'Design & Creative',
    description: 'New organic direct-to-consumer farm produce brand seeking a modern, minimalist emblem logo, color palette, and packaging badge. Looking for student designers who understand clean earthy aesthetics.',
    responsibilities: [
      'Present 3 distinct creative logo concepts with rationale.',
      'Refine the selected concept with full vector assets (SVG, EPS, PNG transparent).',
      'Provide a simple 4-page PDF brand guide with color hex codes and font pairings.'
    ],
    requirements: [
      'Creativity in vector illustration & logo craft (Figma / Illustrator).',
      'Original concepts only (no stock templates or AI generator output).'
    ],
    requiredSkills: ['Graphic Design', 'Figma', 'UI/UX', 'Illustrator'],
    experienceLevel: 'Beginner Friendly',
    numberOfStudents: 1,
    workType: 'Remote',
    location: 'Remote',
    duration: '10 Days',
    availabilityRequirement: 'Flexible',
    minBudget: 4500,
    maxBudget: 7500,
    deadline: '2026-10-20',
    postedDate: '2026-10-03',
    status: 'Active',
    applicantsCount: 8,
    featured: false
  },
  {
    id: 'gig-6',
    title: 'Data Entry and Excel Automation',
    businessId: 'biz-5',
    businessName: 'Apex Logistics Solutions',
    businessType: 'Local Business',
    businessLocation: 'Navi Mumbai',
    businessVerified: true,
    category: 'Data & Analytics',
    description: 'Need a detail-oriented college student to consolidate shipping manifests, warehouse dispatch logs, and invoice records from multiple Excel sheets into an automated master dashboard using formulas / Python scripts.',
    responsibilities: [
      'Cleanse and deduplicate 2,400 raw transport records.',
      'Build dynamic summary pivot tables and VLOOKUP/XLOOKUP formulas.',
      'Optional bonus: Write a basic Python script to automate weekly updates.'
    ],
    requirements: [
      'High proficiency in Microsoft Excel / Google Sheets.',
      'Familiarity with Python (Pandas) is a huge plus.',
      'Punctual and meticulous with data accuracy.'
    ],
    requiredSkills: ['Excel Automation', 'Python', 'Data Analytics'],
    experienceLevel: 'Beginner Friendly',
    numberOfStudents: 1,
    workType: 'Hybrid',
    location: 'Navi Mumbai / Remote',
    duration: '1 Week',
    availabilityRequirement: '12 hrs total',
    minBudget: 4000,
    maxBudget: 6500,
    deadline: '2026-10-14',
    postedDate: '2026-10-04',
    status: 'Active',
    applicantsCount: 7,
    featured: false
  },
  {
    id: 'gig-7',
    title: 'Technical Blog Content Writing for Developer SaaS',
    businessId: 'biz-1',
    businessName: 'TechNova Labs & Studios',
    businessType: 'Startup',
    businessLocation: 'Bengaluru / Remote',
    businessVerified: true,
    category: 'Content & Writing',
    description: 'Looking for a CS or engineering student who loves writing to craft 3 in-depth, hands-on tutorials on "Building Real-time Notifications with WebSockets" and "Dockerizing Spring Boot Applications". Must include code snippets and clear explanations.',
    responsibilities: [
      'Research, draft, and refine three 1,500-word developer articles in Markdown.',
      'Include runnable code blocks and concise step-by-step instructions.',
      'Incorporate clean SEO headings and developer-friendly tone.'
    ],
    requirements: [
      'Strong written English and technical clarity.',
      'Understanding of software engineering concepts.'
    ],
    requiredSkills: ['Content Writing', 'Java', 'Technical Documentation'],
    experienceLevel: 'Intermediate',
    numberOfStudents: 1,
    workType: 'Remote',
    location: 'Remote',
    duration: '2 Weeks',
    availabilityRequirement: '10 hrs/week',
    minBudget: 6000,
    maxBudget: 9000,
    deadline: '2026-10-26',
    postedDate: '2026-10-04',
    status: 'Active',
    applicantsCount: 3,
    featured: false
  }
];

export const INITIAL_APPLICATIONS: Application[] = [
  {
    id: 'app-1',
    gigId: 'gig-1',
    gigTitle: 'Build a College Event Website',
    businessId: 'biz-1',
    businessName: 'TechNova Labs & Studios',
    studentId: 'student-1',
    studentName: 'Aarav Sharma',
    studentCollege: 'MIT World Peace University, Pune',
    studentAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aarav&backgroundColor=c0aede,b6e3f4',
    studentSkills: ['React', 'TypeScript', 'Tailwind CSS', 'UI/UX'],
    studentAvailability: 'Immediate (15-20 hrs/wk)',
    appliedDate: '2026-10-03',
    proposedBudget: 12000,
    coverNote: 'Hi Priya! I previously built the DevSprint hackathon portal for 600+ attendees with interactive schedules and countdown timers. I can build Genesis Hack 2026 in React + Tailwind with silky smooth animations and complete it in 7 days!',
    portfolioLinks: ['https://devsprint26.vercel.app', 'https://auracampus.demo.app'],
    status: 'Under Review',
    timeline: [
      { status: 'Pending', date: '2026-10-03', note: 'Application submitted successfully' },
      { status: 'Under Review', date: '2026-10-04', note: 'Shortlisted by hiring manager Priya for portfolio review' }
    ]
  },
  {
    id: 'app-2',
    gigId: 'gig-3',
    gigTitle: 'Develop a Java Backend API',
    businessId: 'biz-1',
    businessName: 'TechNova Labs & Studios',
    studentId: 'student-3',
    studentName: 'Rohan Verma',
    studentCollege: 'IIT Bombay',
    studentAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rohan&backgroundColor=b6e3f4,c0aede',
    studentSkills: ['Java', 'Spring Boot', 'PostgreSQL', 'Docker'],
    studentAvailability: 'Immediate (15-20 hrs/wk)',
    appliedDate: '2026-10-03',
    proposedBudget: 18000,
    coverNote: 'Experienced in Spring Boot 3, JWT security filters, and JPA caching. Built an order matching engine benchmarked at 10k req/s.',
    portfolioLinks: ['https://github.com/rohanverma/order-engine'],
    status: 'Accepted',
    timeline: [
      { status: 'Pending', date: '2026-10-03', note: 'Application submitted' },
      { status: 'Under Review', date: '2026-10-04', note: 'Profile reviewed' },
      { status: 'Accepted', date: '2026-10-04', note: 'Offer accepted! Milestone 1 kickoff call scheduled.' }
    ]
  },
  {
    id: 'app-3',
    gigId: 'gig-2',
    gigTitle: 'Design Instagram Posts for Local Business',
    businessId: 'biz-2',
    businessName: 'GreenLeaf Artisan Roasters',
    studentId: 'student-2',
    studentName: 'Ananya Deshmukh',
    studentCollege: 'COEP Technological University, Pune',
    studentAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ananya&backgroundColor=ffdfbf,ffd5dc',
    studentSkills: ['UI/UX', 'Figma', 'Graphic Design', 'Instagram Branding'],
    studentAvailability: 'Part-time (10 hrs/wk)',
    appliedDate: '2026-10-02',
    proposedBudget: 7500,
    coverNote: 'I love specialty coffee and design! Handled visual rebranding for Kavya Organics and have crafted 50+ viral Instagram templates.',
    portfolioLinks: ['https://behance.net/ananyadeshmukh'],
    status: 'In Progress',
    timeline: [
      { status: 'Pending', date: '2026-10-02', note: 'Applied' },
      { status: 'Under Review', date: '2026-10-02', note: 'Initial chat' },
      { status: 'Accepted', date: '2026-10-03', note: 'Approved proposal' },
      { status: 'In Progress', date: '2026-10-04', note: 'Drafting initial 6 café posts' }
    ]
  },
  {
    id: 'app-4',
    gigId: 'gig-6',
    gigTitle: 'Data Entry and Excel Automation',
    businessId: 'biz-5',
    businessName: 'Apex Logistics Solutions',
    studentId: 'student-1',
    studentName: 'Aarav Sharma',
    studentCollege: 'MIT World Peace University, Pune',
    studentAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aarav&backgroundColor=c0aede,b6e3f4',
    studentSkills: ['Python', 'Data Analytics', 'Excel Automation'],
    studentAvailability: 'Immediate (15-20 hrs/wk)',
    appliedDate: '2026-09-24',
    proposedBudget: 6000,
    coverNote: 'Automated 2000+ entries using Python OpenPyXL script for student fest attendance. Finished task accurately.',
    portfolioLinks: [],
    status: 'Completed',
    timeline: [
      { status: 'Pending', date: '2026-09-24', note: 'Submitted' },
      { status: 'Accepted', date: '2026-09-25', note: 'Hired' },
      { status: 'Completed', date: '2026-09-28', note: 'Delivered master workbook with zero errors. Payment released!' }
    ],
    rating: 5,
    clientFeedback: 'Aarav completed the automation ahead of deadline and wrote clear instructions. Outstanding student freelancer!'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    userId: 'student-1',
    role: 'student',
    title: 'Application Under Review',
    message: 'Priya Nambiar from TechNova Labs reviewed your application for "Build a College Event Website".',
    time: '2 hours ago',
    read: false,
    type: 'application',
    linkTab: 'my-applications'
  },
  {
    id: 'notif-2',
    userId: 'student-1',
    role: 'student',
    title: 'New Recommended Gig (96% Match)',
    message: 'A new gig matching your Java & Spring Boot skills was just posted: "Develop a Java Backend API".',
    time: '5 hours ago',
    read: false,
    type: 'gig',
    linkTab: 'find-gigs'
  },
  {
    id: 'notif-3',
    userId: 'biz-1',
    role: 'business',
    title: 'New Applicant for Hackathon Website',
    message: 'Aarav Sharma (MIT WPU, 4.9★) applied with custom portfolio links.',
    time: '1 day ago',
    read: false,
    type: 'application',
    linkTab: 'applications'
  },
  {
    id: 'notif-4',
    userId: 'student-1',
    role: 'student',
    title: 'Gig Completed & Payment Released',
    message: 'Apex Logistics rated your work 5.0★ and transferred ₹6,000 for Excel Automation.',
    time: '4 days ago',
    read: true,
    type: 'system',
    linkTab: 'my-applications'
  }
];

export const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    senderId: 'biz-1',
    senderName: 'Priya Nambiar (TechNova Labs)',
    senderRole: 'business',
    recipientId: 'student-1',
    gigTitle: 'Build a College Event Website',
    text: 'Hey Aarav! Impressive work on DevSprint portal. Do you have experience integrating Google Sheets API for real-time ticket counters?',
    timestamp: 'Today, 2:30 PM'
  },
  {
    id: 'msg-2',
    senderId: 'student-1',
    senderName: 'Aarav Sharma',
    senderRole: 'student',
    recipientId: 'biz-1',
    gigTitle: 'Build a College Event Website',
    text: 'Hi Priya! Yes, absolutely. I hooked up Google Sheets as a light CMS with 5-minute caching on Vercel edge functions. Super reliable and zero backend maintenance cost for event sponsors!',
    timestamp: 'Today, 2:38 PM'
  }
];

export const POPULAR_SKILLS = [
  { name: 'React', count: '142 Gigs', category: 'Tech', icon: 'Code' },
  { name: 'Java', count: '98 Gigs', category: 'Tech', icon: 'Terminal' },
  { name: 'UI/UX', count: '115 Gigs', category: 'Design', icon: 'Figma' },
  { name: 'Python', count: '124 Gigs', category: 'Tech', icon: 'Cpu' },
  { name: 'Graphic Design', count: '89 Gigs', category: 'Design', icon: 'Palette' },
  { name: 'Video Editing', count: '76 Gigs', category: 'Media', icon: 'Video' },
  { name: 'Content Writing', count: '64 Gigs', category: 'Content', icon: 'FileText' },
  { name: 'Excel Automation', count: '52 Gigs', category: 'Data', icon: 'Table' }
];

export const PLATFORM_STATS = [
  { label: 'Active College Freelancers', value: '1,450+', subtext: 'From 80+ partner campuses' },
  { label: 'Gigs Completed', value: '620+', subtext: 'With 98% client satisfaction' },
  { label: 'Earned by Students', value: '₹28.4 Lakhs', subtext: 'Direct verified bank payouts' },
  { label: 'Avg. Hiring Turnaround', value: '48 Hours', subtext: 'Faster than traditional agencies' }
];
