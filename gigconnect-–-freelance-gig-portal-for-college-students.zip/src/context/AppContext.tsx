import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserRole,
  StudentProfile,
  BusinessProfile,
  Gig,
  Application,
  NotificationItem,
  ChatMessage,
  ToastMessage,
  ApplicationStatus
} from '../types';
import {
  INITIAL_STUDENT,
  INITIAL_BUSINESS,
  INITIAL_GIGS,
  INITIAL_APPLICATIONS,
  INITIAL_NOTIFICATIONS,
  INITIAL_MESSAGES,
  OTHER_STUDENTS
} from '../data/mockData';

interface AppContextType {
  role: UserRole;
  currentStudent: StudentProfile;
  currentBusiness: BusinessProfile;
  allStudents: StudentProfile[];
  gigs: Gig[];
  applications: Application[];
  savedGigIds: string[];
  notifications: NotificationItem[];
  messages: ChatMessage[];
  toasts: ToastMessage[];

  // Navigation & View State
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedGigId: string | null;
  setSelectedGigId: (id: string | null) => void;

  // Modals & Panels
  authModal: { isOpen: boolean; mode: 'login' | 'register'; defaultRole: 'student' | 'business' };
  openAuthModal: (mode?: 'login' | 'register', defaultRole?: 'student' | 'business') => void;
  closeAuthModal: () => void;
  applyModalGig: Gig | null;
  openApplyModal: (gig: Gig) => void;
  closeApplyModal: () => void;
  postGigModalOpen: boolean;
  setPostGigModalOpen: (open: boolean) => void;
  viewStudentModal: StudentProfile | null;
  setViewStudentModal: (student: StudentProfile | null) => void;
  notificationsOpen: boolean;
  setNotificationsOpen: (open: boolean) => void;
  messagesOpen: boolean;
  setMessagesOpen: (open: boolean) => void;
  
  // Actions
  loginAsStudent: (student?: Partial<StudentProfile>) => void;
  loginAsBusiness: (biz?: Partial<BusinessProfile>) => void;
  logout: () => void;
  switchRole: (role: UserRole) => void;
  applyToGig: (gigId: string, coverNote: string, proposedBudget: number, portfolioLinks: string[]) => boolean;
  toggleSaveGig: (gigId: string) => void;
  isGigSaved: (gigId: string) => boolean;
  postGig: (newGig: Omit<Gig, 'id' | 'businessId' | 'businessName' | 'businessType' | 'postedDate' | 'status' | 'applicantsCount' | 'businessVerified' | 'businessLocation'>) => void;
  updateApplicationStatus: (appId: string, newStatus: ApplicationStatus, note?: string) => void;
  updateStudentProfile: (profile: Partial<StudentProfile>) => void;
  updateBusinessProfile: (profile: Partial<BusinessProfile>) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  sendChatMessage: (text: string, gigTitle?: string) => void;
  calculateMatchScore: (requiredSkills: string[], studentSkills?: string[]) => number;
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  ROLE: 'gigconnect_role',
  STUDENT: 'gigconnect_student',
  BUSINESS: 'gigconnect_business',
  GIGS: 'gigconnect_gigs',
  APPLICATIONS: 'gigconnect_applications',
  SAVED_GIGS: 'gigconnect_saved_gigs',
  NOTIFICATIONS: 'gigconnect_notifications',
  MESSAGES: 'gigconnect_messages'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persistence loaders
  const [role, setRoleState] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE);
    return (saved as UserRole) || 'guest';
  });

  const [currentStudent, setCurrentStudent] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STUDENT);
    return saved ? JSON.parse(saved) : INITIAL_STUDENT;
  });

  const [currentBusiness, setCurrentBusiness] = useState<BusinessProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BUSINESS);
    return saved ? JSON.parse(saved) : INITIAL_BUSINESS;
  });

  const [gigs, setGigs] = useState<Gig[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GIGS);
    return saved ? JSON.parse(saved) : INITIAL_GIGS;
  });

  const [applications, setApplications] = useState<Application[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.APPLICATIONS);
    return saved ? JSON.parse(saved) : INITIAL_APPLICATIONS;
  });

  const [savedGigIds, setSavedGigIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SAVED_GIGS);
    return saved ? JSON.parse(saved) : ['gig-1', 'gig-3'];
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Navigation state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedGigId, setSelectedGigId] = useState<string | null>(null);

  // Modals state
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; mode: 'login' | 'register'; defaultRole: 'student' | 'business' }>({
    isOpen: false,
    mode: 'login',
    defaultRole: 'student'
  });

  const [applyModalGig, setApplyModalGig] = useState<Gig | null>(null);
  const [postGigModalOpen, setPostGigModalOpen] = useState(false);
  const [viewStudentModal, setViewStudentModal] = useState<StudentProfile | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [messagesOpen, setMessagesOpen] = useState(false);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENT, JSON.stringify(currentStudent));
  }, [currentStudent]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BUSINESS, JSON.stringify(currentBusiness));
  }, [currentBusiness]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GIGS, JSON.stringify(gigs));
  }, [gigs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVED_GIGS, JSON.stringify(savedGigIds));
  }, [savedGigIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  }, [messages]);

  // Toast Helpers
  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Auth & Role Helpers
  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    if (newRole === 'guest') {
      setActiveTab('landing');
    } else {
      setActiveTab('dashboard');
    }
  };

  const loginAsStudent = (data?: Partial<StudentProfile>) => {
    if (data) {
      setCurrentStudent(prev => ({ ...prev, ...data }));
    }
    setRole('student');
    setAuthModal(prev => ({ ...prev, isOpen: false }));
    addToast({
      type: 'success',
      title: 'Logged in as Student',
      message: `Welcome back, ${data?.name || currentStudent.name}! You are ready to explore gigs.`
    });
  };

  const loginAsBusiness = (biz?: Partial<BusinessProfile>) => {
    if (biz) {
      setCurrentBusiness(prev => ({ ...prev, ...biz }));
    }
    setRole('business');
    setAuthModal(prev => ({ ...prev, isOpen: false }));
    addToast({
      type: 'success',
      title: 'Logged in as Business Client',
      message: `Welcome back, ${biz?.name || currentBusiness.name}! Managing gigs for ${biz?.companyName || currentBusiness.companyName}.`
    });
  };

  const logout = () => {
    setRole('guest');
    addToast({
      type: 'info',
      title: 'Signed Out',
      message: 'You have been logged out to guest view.'
    });
  };

  const switchRole = (newRole: UserRole) => {
    setRole(newRole);
    if (newRole === 'student') {
      addToast({ type: 'info', title: 'Switched Role', message: `Active session: ${currentStudent.name} (Student)` });
    } else if (newRole === 'business') {
      addToast({ type: 'info', title: 'Switched Role', message: `Active session: ${currentBusiness.name} (${currentBusiness.companyName})` });
    } else {
      addToast({ type: 'info', title: 'Guest View', message: 'Browsing public platform showcase.' });
    }
  };

  const openAuthModal = (mode: 'login' | 'register' = 'login', defaultRole: 'student' | 'business' = 'student') => {
    setAuthModal({ isOpen: true, mode, defaultRole });
  };

  const closeAuthModal = () => {
    setAuthModal(prev => ({ ...prev, isOpen: false }));
  };

  const openApplyModal = (gig: Gig) => {
    setApplyModalGig(gig);
  };

  const closeApplyModal = () => {
    setApplyModalGig(null);
  };

  // Gig Actions
  const toggleSaveGig = (gigId: string) => {
    setSavedGigIds(prev => {
      const exists = prev.includes(gigId);
      if (exists) {
        addToast({ type: 'info', title: 'Gig Removed', message: 'Removed from your saved gigs.' });
        return prev.filter(id => id !== gigId);
      } else {
        addToast({ type: 'success', title: 'Gig Saved', message: 'Added to your bookmarked opportunities.' });
        return [...prev, gigId];
      }
    });
  };

  const isGigSaved = (gigId: string) => savedGigIds.includes(gigId);

  // Match algorithm: checks overlap between required skills and student's skills
  const calculateMatchScore = (requiredSkills: string[], studentSkills: string[] = currentStudent.skills): number => {
    if (!requiredSkills.length) return 85;
    const lowerStudentSkills = studentSkills.map(s => s.toLowerCase());
    const matches = requiredSkills.filter(req =>
      lowerStudentSkills.some(stud => stud.includes(req.toLowerCase()) || req.toLowerCase().includes(stud))
    );
    const ratio = matches.length / requiredSkills.length;
    // Map from 60% minimum baseline to 98%
    const score = Math.round(65 + ratio * 33);
    return Math.min(score, 98);
  };

  // Student applies to gig
  const applyToGig = (gigId: string, coverNote: string, proposedBudget: number, portfolioLinks: string[]): boolean => {
    const targetGig = gigs.find(g => g.id === gigId);
    if (!targetGig) return false;

    // Check if already applied
    const alreadyApplied = applications.some(a => a.gigId === gigId && a.studentId === currentStudent.id);
    if (alreadyApplied) {
      addToast({
        type: 'info',
        title: 'Already Applied',
        message: 'You have already submitted an application for this gig.'
      });
      return false;
    }

    const newApp: Application = {
      id: 'app-' + Date.now(),
      gigId: targetGig.id,
      gigTitle: targetGig.title,
      businessId: targetGig.businessId,
      businessName: targetGig.businessName,
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      studentCollege: currentStudent.college,
      studentAvatar: currentStudent.avatar,
      studentSkills: currentStudent.skills,
      studentAvailability: currentStudent.availability,
      appliedDate: new Date().toISOString().split('T')[0],
      proposedBudget,
      coverNote,
      portfolioLinks: portfolioLinks.length ? portfolioLinks : currentStudent.portfolio.map(p => p.link),
      status: 'Pending',
      timeline: [
        {
          status: 'Pending',
          date: new Date().toISOString().split('T')[0],
          note: 'Application submitted successfully to client'
        }
      ]
    };

    setApplications(prev => [newApp, ...prev]);

    // Update applicant count on gig
    setGigs(prev =>
      prev.map(g => (g.id === gigId ? { ...g, applicantsCount: g.applicantsCount + 1 } : g))
    );

    // Add notification for both
    setNotifications(prev => [
      {
        id: 'notif-' + Date.now(),
        userId: currentStudent.id,
        role: 'student',
        title: 'Application Submitted!',
        message: `Your proposal for "${targetGig.title}" was submitted to ${targetGig.businessName}.`,
        time: 'Just now',
        read: false,
        type: 'application',
        linkTab: 'my-applications'
      },
      {
        id: 'notif-b-' + Date.now(),
        userId: targetGig.businessId,
        role: 'business',
        title: 'New Applicant Received',
        message: `${currentStudent.name} applied for "${targetGig.title}".`,
        time: 'Just now',
        read: false,
        type: 'application',
        linkTab: 'applications'
      },
      ...prev
    ]);

    addToast({
      type: 'success',
      title: 'Application Submitted!',
      message: `Your pitch for "${targetGig.title}" has been sent to ${targetGig.businessName}.`
    });

    closeApplyModal();
    return true;
  };

  // Business posts a new gig
  const postGig = (gigInput: Omit<Gig, 'id' | 'businessId' | 'businessName' | 'businessType' | 'postedDate' | 'status' | 'applicantsCount' | 'businessVerified' | 'businessLocation'>) => {
    const newGig: Gig = {
      ...gigInput,
      id: 'gig-' + Date.now(),
      businessId: currentBusiness.id,
      businessName: currentBusiness.companyName,
      businessType: currentBusiness.organizationType,
      businessLocation: currentBusiness.location,
      businessVerified: currentBusiness.verified,
      postedDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      applicantsCount: 0,
      featured: true
    };

    setGigs(prev => [newGig, ...prev]);
    setCurrentBusiness(prev => ({ ...prev, activeGigsCount: prev.activeGigsCount + 1 }));

    // Create system notification for students
    setNotifications(prev => [
      {
        id: 'notif-new-' + Date.now(),
        userId: 'student-1',
        role: 'student',
        title: 'New Gig Alert 🚀',
        message: `${currentBusiness.companyName} just posted "${newGig.title}". Check match score!`,
        time: 'Just now',
        read: false,
        type: 'gig',
        linkTab: 'find-gigs'
      },
      ...prev
    ]);

    addToast({
      type: 'success',
      title: 'Gig Published Live!',
      message: `"${newGig.title}" is now visible to thousands of campus students.`
    });

    setPostGigModalOpen(false);
  };

  // Business reviews & updates application status
  const updateApplicationStatus = (appId: string, newStatus: ApplicationStatus, note?: string) => {
    setApplications(prev =>
      prev.map(app => {
        if (app.id !== appId) return app;

        const updatedTimeline = [
          ...app.timeline,
          {
            status: newStatus,
            date: new Date().toISOString().split('T')[0],
            note: note || `Status updated to ${newStatus}`
          }
        ];

        return {
          ...app,
          status: newStatus,
          timeline: updatedTimeline,
          clientFeedback: note || app.clientFeedback
        };
      })
    );

    const appItem = applications.find(a => a.id === appId);
    if (appItem) {
      // Notify student
      setNotifications(prev => [
        {
          id: 'notif-status-' + Date.now(),
          userId: appItem.studentId,
          role: 'student',
          title: `Application ${newStatus}`,
          message: `${appItem.businessName} updated your status on "${appItem.gigTitle}" to ${newStatus}.`,
          time: 'Just now',
          read: false,
          type: 'application',
          linkTab: 'my-applications'
        },
        ...prev
      ]);
    }

    addToast({
      type: 'success',
      title: 'Application Updated',
      message: `Candidate status marked as ${newStatus}.`
    });
  };

  // Profile updaters
  const updateStudentProfile = (profile: Partial<StudentProfile>) => {
    setCurrentStudent(prev => ({ ...prev, ...profile }));
    addToast({
      type: 'success',
      title: 'Profile Updated',
      message: 'Your student profile and skills showcase were saved.'
    });
  };

  const updateBusinessProfile = (profile: Partial<BusinessProfile>) => {
    setCurrentBusiness(prev => ({ ...prev, ...profile }));
    addToast({
      type: 'success',
      title: 'Company Profile Updated',
      message: 'Your business details and hiring preferences were saved.'
    });
  };

  // Notification actions
  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    addToast({ type: 'info', title: 'Notifications', message: 'All notifications marked as read.' });
  };

  // Messages
  const sendChatMessage = (text: string, gigTitle?: string) => {
    if (!text.trim()) return;
    const isStudent = role === 'student';
    const newMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      senderId: isStudent ? currentStudent.id : currentBusiness.id,
      senderName: isStudent ? currentStudent.name : currentBusiness.name,
      senderRole: isStudent ? 'student' : 'business',
      recipientId: isStudent ? currentBusiness.id : currentStudent.id,
      text: text.trim(),
      timestamp: 'Just now',
      gigTitle: gigTitle || 'Build a College Event Website'
    };

    setMessages(prev => [...prev, newMsg]);

    // Simulated reply after 1.5 seconds for interactive hackathon showcase
    setTimeout(() => {
      const replyMsg: ChatMessage = {
        id: 'msg-reply-' + Date.now(),
        senderId: isStudent ? currentBusiness.id : currentStudent.id,
        senderName: isStudent ? `${currentBusiness.name} (Hiring Lead)` : `${currentStudent.name} (Student)`,
        senderRole: isStudent ? 'business' : 'student',
        recipientId: isStudent ? currentStudent.id : currentBusiness.id,
        text: isStudent
          ? 'Got your message! We reviewed your milestones and everything looks promising. Let us finalize the project kickoff!'
          : 'Thank you for reaching out! I am available to start immediately and will share the GitHub repo link soon.',
        timestamp: 'Just now',
        gigTitle: gigTitle || 'Build a College Event Website'
      };
      setMessages(prev => [...prev, replyMsg]);
      addToast({
        type: 'info',
        title: 'New Message Received',
        message: `${replyMsg.senderName} responded to your inquiry.`
      });
    }, 1800);
  };

  // Reset all data
  const resetAllData = () => {
    localStorage.clear();
    setCurrentStudent(INITIAL_STUDENT);
    setCurrentBusiness(INITIAL_BUSINESS);
    setGigs(INITIAL_GIGS);
    setApplications(INITIAL_APPLICATIONS);
    setSavedGigIds(['gig-1', 'gig-3']);
    setNotifications(INITIAL_NOTIFICATIONS);
    setMessages(INITIAL_MESSAGES);
    setRole('guest');
    setActiveTab('landing');
    addToast({
      type: 'info',
      title: 'Demo Data Reset',
      message: 'All sample data, gigs, and applications restored to factory defaults.'
    });
  };

  const allStudents = [currentStudent, ...OTHER_STUDENTS];

  return (
    <AppContext.Provider
      value={{
        role,
        currentStudent,
        currentBusiness,
        allStudents,
        gigs,
        applications,
        savedGigIds,
        notifications,
        messages,
        toasts,
        activeTab,
        setActiveTab,
        selectedGigId,
        setSelectedGigId,
        authModal,
        openAuthModal,
        closeAuthModal,
        applyModalGig,
        openApplyModal,
        closeApplyModal,
        postGigModalOpen,
        setPostGigModalOpen,
        viewStudentModal,
        setViewStudentModal,
        notificationsOpen,
        setNotificationsOpen,
        messagesOpen,
        setMessagesOpen,
        loginAsStudent,
        loginAsBusiness,
        logout,
        switchRole,
        applyToGig,
        toggleSaveGig,
        isGigSaved,
        postGig,
        updateApplicationStatus,
        updateStudentProfile,
        updateBusinessProfile,
        markNotificationRead,
        markAllNotificationsRead,
        sendChatMessage,
        calculateMatchScore,
        addToast,
        removeToast,
        resetAllData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
